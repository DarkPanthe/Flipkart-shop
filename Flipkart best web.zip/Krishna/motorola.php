<!DOCTYPE html><html lang="en-IN"><head>

    <title>Motorola razr 40 Ultra (Glacier Blue, 8GB RAM, 256GB Storage)External AMOLED Display</title>
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    
    <meta name="Keywords" content="Online Shopping in India,online Shopping store,Online Shopping Site,Buy Online,Shop Online,Online Shopping, Fliipkart">
    <meta name="Description" content="India's biggest online store for Mobiles, Fashion (Clothes/Shoes), Electronics, Home Appliances, Books, Home, Furniture, Grocery, Jewelry, Sporting goods, Beauty &amp; Personal Care and more! Find the largest selection from all brands at the lowest prices in India. &amp; more.">
    <meta property="og:title" content="Online Shopping India Lifestyle Mobile, Cameras, &amp; more Online @ Fliipkart.com">
    <meta name="theme-color" content="#2874f0" id="themeColor">
    <meta name="viewport" content="width=device-width,minimum-scale=1,user-scalable=no">
    <link rel="shortcut icon" href="images/favicon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main1.css">
    <link rel="stylesheet" href="css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
    <script src="js/jquery.min.js"></script>
    <meta name="google-site-verification" content="WGDp73cQJI4DXzpyPaTV1VGDeKLhNaoZDoM0kjCbPnU">
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&amp;display=swap" rel="stylesheet">
    <script> var MAIN_URL = ''; </script>
    <style>
        body,
        a,
        p,
        span,
        div,
        input,
        button,
        h1,
        h2,
        h3,
        h4,
        h5,
        h6,
        button,
        input,
        optgroup,
        select,
        textarea {
                font-family: Roboto, Helvetica, Arial, sans-serif !important;
        }
        .button-container {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    box-shadow: -4px 3px 7px #bdbbbb;
    -webkit-box-align: center;
    align-items: center;
    display: flex;
    -webkit-box-pack: justify;
    justify-content: space-between;
    width: 100%;
    background-color: rgb(255, 255, 255);
    border-radius: 0px;
    height: 58px;
    z-index:99;
}

.buynow-button {
    z-index: 9999999999999999;
    background: #ffc200;
    display: block;
    color: #000;
    position: relative;
    overflow: hidden;
    border-radius: 0px;
    border: 0px solid #ffc200;
    font-size: 14px;
    padding: 6px 9px;
}

.add_cart {
    z-index: 9999999999999999;
    width: 50%;
    flex: 1 1 0%;
    display: flex;
    -webkit-box-pack: center;
    justify-content: center;
    cursor: pointer;
    font-style: normal;
    text-align: center;
    letter-spacing: 0.0015em;
    font-size: 15px;
    line-height: 34px;
    border: none !important;
    color: #000000;
    background: center center rgb(255, 255, 255);
    padding: 12px;
    transition: background 0.8s ease 0s;
    column-gap: 10px;
}

.buy_now {
    
    z-index: 9999999999999999;
    width: 50%;
    flex: 1 1 0%;
    display: flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    cursor: pointer;
    font-style: normal;
    text-align: center;
    letter-spacing: 0.0015em;
    font-size: 15px;
    line-height: 46px;
    border: none !important;
    color: #000000;
    background: center center #ffc200;
    border: none;
    /*padding: 12px;*/
    transition: background 0.8s ease 0s;
    column-gap: 10px;
}
    </style>
</head>

<body class="expansion-alids-init" cz-shortcut-listen="true">
    <div class="container-fluid">
        <div class="_1FWdmb" style="">
            <div class="d-flex align-items-center">
                <a class="_3NH1qf " id="back-btn">
                    <svg width="19" height="16" viewBox="0 0 19 16" xmlns="http://www.w3.org/2000/svg">
                        <path d="M17.556 7.847H1M7.45 1L1 7.877l6.45 6.817" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"></path>
                    </svg>
                </a>
                <a class="_3NH1qf d-none" id="showmenu">
                    <svg width="100%" height="100%" fill="none" xmlns="http://www.w3.org/2000/svg" mt="5" iconsize="24" class="sc-gswNZR jQgwzc">
                        <path d="M2 17.2222C2 17.8359 2.49746 18.3333 3.11111 18.3333H20.8889C21.5025 18.3333 22 17.8359 22 17.2222C22 16.6086 21.5025 16.1111 20.8889 16.1111H3.11111C2.49746 16.1111 2 16.6086 2 17.2222ZM2 11.6667C2 12.2803 2.49746 12.7778 3.11111 12.7778H20.8889C21.5025 12.7778 22 12.2803 22 11.6667C22 11.053 21.5025 10.5556 20.8889 10.5556H3.11111C2.49746 10.5556 2 11.053 2 11.6667ZM3.11111 5C2.49746 5 2 5.49746 2 6.11111C2 6.72476 2.49746 7.22222 3.11111 7.22222H20.8889C21.5025 7.22222 22 6.72476 22 6.11111C22 5.49746 21.5025 5 20.8889 5H3.11111Z" fill="#333333"></path>
                    </svg>
                </a>
                <a class="Z4_K_h" style="width:auto;height:auto;margin-right:10px;margin-left:10px" href="index.php">
                    <img class="logop" style="width:25px;" src="images/favicon.png">
                </a>
                
            </div>
            <div class="header-menu">
                <div class="right-area _2msBFL">
                    <div class="dwddsad">
                        <a class="_1krdK5 vbCXhM" href="" title="Login"><img src="images/profile.svg" alt="Login" class="_1XmrCc _2zJ7Pb" width="24" height="24"><div class="uiU-ZX">Login</div></a>
                    </div>
                    <div class="cart">
                    <a href="" title="Cart" class="_3RX0a-"><img src="images/cart.svg" alt="Cart" class="_1XmrCc" width="24" height="24"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    


   
                            
                        
        <div class="container-fluid px-0 product-slider">
            <div class="gghfy456657">
                <div class="css-175oi2r" style="margin-top:10px;margin-right:16px;transform:translateX(0px)">
                    <div class="css-175oi2r">
                        <div>
                            <div class="css-175oi2r" style="align-items:center;justify-content:center;padding-left:8px;padding-right:8px;padding-top:8px;padding-bottom:8px">
                                <div class="css-175oi2r"><svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#717478" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="css-175oi2r" style="margin-top:14px;margin-right:16px;transform:translateX(0px)">
                    <div class="css-175oi2r r-1awozwy r-y47klf r-eu3ka r-1777fci r-1aockid">
                        <div tabindex="0" class="css-175oi2r" style="padding-left:8px;padding-right:8px;padding-top:8px;padding-bottom:8px"><svg width="24" height="24" fill="none" viewBox="0 0 22 22"><path fill-rule="evenodd" clip-rule="evenodd" d="M13.187 2.316v4.323c-7.655 1.08-10.936 6.484-12.03 11.887 2.735-3.782 6.562-5.511 12.03-5.511v4.43l7.655-7.564-7.655-7.565Z" fill="#fff" stroke="#717478"></path></svg></div>
                    </div>
                </div>
            </div>
            <div id="sliderX" class="carousel slide" data-ride="carousel">
                <ol class="carousel-indicators">
                    <li data-bs-target="#sliderX" data-bs-slide-to="0" class="active"></li>
                                        <li data-bs-target="#sliderX" data-bs-slide-to="1" class=""></li>
                                        <li data-bs-target="#sliderX" data-bs-slide-to="2" class=""></li>
                                        <li data-bs-target="#sliderX" data-bs-slide-to="3" class=""></li>
                                        <li data-bs-target="#sliderX" data-bs-slide-to="4" class=""></li>
                                        <li data-bs-target="#sliderX" data-bs-slide-to="5" class=""></li>
                                        <li data-bs-target="#sliderX" data-bs-slide-to="6" class=""></li>
                                    </ol>
                <div class="carousel-inner">
                    <div class="carousel-item active ">
                        <img class="d-block w-100 main_image  slider-item-1" src="images/617WN7I3E4L._SX679_.jpg" alt="First slide">
                    </div>
                                        <div class="carousel-item">
                        <img class="d-block w-100   slider-item-6" src=" https://m.media-amazon.com/images/I/61aNOD9bXLL._SX679_.jpg" alt="First slide">
                    </div>
                                        <div class="carousel-item">
                        <img class="d-block w-100   slider-item-6" src=" https://m.media-amazon.com/images/I/61ZYM5QLktL._SX679_.jpg" alt="First slide">
                    </div>
                                        <div class="carousel-item">
                        <img class="d-block w-100   slider-item-6" src=" https://m.media-amazon.com/images/I/61ze2rKuuoL._SX679_.jpg" alt="First slide">
                    </div>
                                        <div class="carousel-item">
                        <img class="d-block w-100   slider-item-6" src=" https://m.media-amazon.com/images/I/617D7U0bJ-L._SX679_.jpg" alt="First slide">
                    </div>
                                        <div class="carousel-item">
                        <img class="d-block w-100   slider-item-6" src=" https://m.media-amazon.com/images/I/61Ko57ceUkL._SX679_.jpg" alt="First slide">
                    </div>
                                        <div class="carousel-item">
                        <img class="d-block w-100   slider-item-6" src=" https://m.media-amazon.com/images/I/61UDI-pyP7L._SX679_.jpg" alt="First slide">
                    </div>
                                                            
                </div>
            </div>
            <div class="gdffg5676575">
                <div class="css-175oi2r r-18u37iz r-1awozwy r-1e081e0 r-kzbkwu r-glunga fdgdfgd645">
                    <div style="display: flex; position: relative; width: 24px; height: 24px;">
                        <img src="images/e2ee7c1c-ec9e-4ae7-b5dd-6b2685299686.webp" style="    padding: 0;width: 100%; height: 100%; margin: auto; object-fit: contain; opacity: 1;">
                    </div>
                    <div class="sdvd565" style="margin-left: 6px;">
                        <div class="fegeg667657">523  people ordered this in the last 30 days</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid mt-05">
                        <div class="" style="margin-right: 16px; margin-left: 16px;padding: 15px 0;">
                <div class="css-175oi2r r-1mwlp6a">
                    <div dir="auto" class="css-1rynq56 r-1vgyyaa r-ubezar r-1472mwg r-135wba7 r-1ifxtd0 r-1ow6zhx r-1wzrnnt" style="    font-size: 17px;">Select Variant</div>
                </div>
            </div>
                                    <div class="border-1 mt-05 mb-05"></div>
            <div class="" style="margin-right: 16px; margin-left: 16px;" onclick="openNav()">
                <div class="dfs8f">
                    <div class="fgd542gf">
                        <div dir="auto" class="css-1rynq56 r-dnmrzs r-1udh08x r-1udbk01 r-3s2u2q r-1iln25a r-op4f77 r-1et8rh5 r-1b43r93 r-1rsjblm r-1777fci r-135wba7">Color<!-- -->:<span class="css-1qaijid r-1vgyyaa show_color"> Peach Fuzz  </span></div>
                    </div>
                    <div class="fgd542gf">
                        <div dir="auto" class="css-1rynq56 r-1h7g6bg r-1et8rh5 r-1b43r93 r-135wba7 r-19einr3">3<!-- --> <!-- -->more</div>
                        <svg width="17" height="17" fill="none" viewBox="0 0 17 17"><path d="m6.627 3.749 5 5-5 5" stroke="#111112" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                    </div>
                </div>
            </div>
            
                                    <div class="border-1 mt-05 mb-05"></div>
            <div class="" style="margin-right: 16px; margin-left: 16px;" onclick="openNav()">
                <div class="dfs8f">
                    <div class="fgd542gf">
                        <div dir="auto" class="css-1rynq56 r-dnmrzs r-1udh08x r-1udbk01 r-3s2u2q r-1iln25a r-op4f77 r-1et8rh5 r-1b43r93 r-1rsjblm r-1777fci r-135wba7">Storage<!-- -->:<span class="css-1qaijid r-1vgyyaa show_storage"> 256 Gb</span></div>
                    </div>
                    <div class="fgd542gf">
                        <div dir="auto" class="css-1rynq56 r-1h7g6bg r-1et8rh5 r-1b43r93 r-135wba7 r-19einr3">0<!-- --> <!-- -->more</div>
                        <svg width="17" height="17" fill="none" viewBox="0 0 17 17"><path d="m6.627 3.749 5 5-5 5" stroke="#111112" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                    </div>
                </div>
            </div>
            
                                </div>
        <div class="border-2 mt-05 mb-05"></div>

        <div id="mySidenav" class="sidenav" style="right: -100%;">
            <div class="sidenav-div">
                <div class="dasdf543">
                    <a href="javascript:void(0)" class="closebtn2" onclick="closeNav()">×</a>
                    <span style="font-size: 19px;    line-height: 32px;">Select Variant</span>
                </div>
                
            </div>
            
            
            <div class="border-1 mb-05"></div>
            <div class="" style="margin-right: 16px; margin-left: 16px;    padding-top: 10px;">
                <span class="css-1qaijid product-title" style="color: rgb(96 96 96); font-size: 17px; line-height: 20px; font-weight: 400; font-family: inter_regular; letter-spacing: -0.01px;">Motorola razr 40 Ultra (Glacier Blue, 8GB RAM, 256GB Storage)External AMOLED Display</span>     
                <div class="product-price d-flex my-2" style="    margin-top: 11px !important;">
                    <span class="mrp fsdfd54" style="margin:0;" data-mrp="41999">₹41,999</span>
                    <span class="price dfgee5646" style="margin-left: 10px !important;    font-size: 24px !important;font-family: Roboto Medium, Roboto-Medium, Droid Sans, HelveticaNeue-Medium, Helvetica Neue Medium, sans-serif-medium;!important" data-price="689">₹689</span>
                    <span class="discount fbbg46454" style="margin-left:10px;">98% off</span>
                </div>
            </div> 
            <div class="border-1 mb-05 mt-15"></div>
            <div class="fdsfs546" style="margin-right: 16px; margin-left: 16px;    padding-top: 10px;">
                <div class="color-div">
                    <h4 style="font-size:18px;font-weight: 600;margin-bottom: 20px;">Select Color</h4>
                                        <div class="color-list p-2">
                                                <div class="color-box color-item p-2 me-2 active " data-mrp="41999" data-selling-price="689" onclick="manage_color_click($(this),'Peach Fuzz','0',0, 'https://m.media-amazon.com/images/I/61UDI-pyP7L._SX679_.jpg');">
                                <div class="color-div" style="height: 50px;">
                                    <img src="images/61UDI-pyP7L._SX679_.jpg" alt="img0" class="color_img_0" style="overflow: hidden;height: 100%;object-fit: contain;width: 47px;">  
                                </div>
                            
                            <div style="background-color: Peach Fuzz" class="color-round  color-item-box"></div>
                            <span class="color-name"> Peach Fuzz</span>
                        </div>
                                                <div class="color-box color-item p-2 me-2  " data-mrp="41999" data-selling-price="689" onclick="manage_color_click($(this),'Black','0',0, 'https://m.media-amazon.com/images/I/617D7U0bJ-L._SX679_.jpg');">
                                <div class="color-div" style="height: 50px;">
                                    <img src="images/617D7U0bJ-L._SX679_.jpg" alt="img0" class="color_img_0" style="overflow: hidden;height: 100%;object-fit: contain;width: 47px;">  
                                </div>
                            
                            <div style="background-color: Black" class="color-round  color-item-box"></div>
                            <span class="color-name"> Black</span>
                        </div>
                                                <div class="color-box color-item p-2 me-2  " data-mrp="41999" data-selling-price="689" onclick="manage_color_click($(this),'Magenta','0',0, 'https://m.media-amazon.com/images/I/617WN7I3E4L._SX679_.jpg');">
                                <div class="color-div" style="height: 50px;">
                                    <img src="images/617WN7I3E4L._SX679_.jpg" alt="img0" class="color_img_0" style="overflow: hidden;height: 100%;object-fit: contain;width: 47px;">  
                                </div>
                            
                            <div style="background-color: Magenta" class="color-round  color-item-box"></div>
                            <span class="color-name"> Magenta</span>
                        </div>
                                                <div class="color-box color-item p-2 me-2  " data-mrp="41999" data-selling-price="689" onclick="manage_color_click($(this),'Glacier Blue','0',0, 'https://m.media-amazon.com/images/I/61Of9aBQPVL._SX679_.jpg');">
                                <div class="color-div" style="height: 50px;">
                                    <img src="images/61Of9aBQPVL._SX679_.jpg" alt="img0" class="color_img_0" style="overflow: hidden;height: 100%;object-fit: contain;width: 47px;">  
                                </div>
                            
                            <div style="background-color: Glacier Blue" class="color-round  color-item-box"></div>
                            <span class="color-name"> Glacier Blue</span>
                        </div>
                                            </div>                              
                                    </div>
                                <div class="sc-kDvujY iGlGaV SizeSelectionstyled__SizeCard-sc-155vsje-0 eeldyg SizeSelectionstyled__SizeCard-sc-155vsje-0 eeldyg" color="white">
                    <div class="storage-div mt-3">
                        <h4 style="font-size: 18px;font-weight: 600;margin-bottom: 20px;">Select Storage</h4>
                        <div class="storage-list p-2">
                                                        <div class="storage-item p-2 me-2 mb-2 256Gb active" data-selling-price="689" data-mrp="41999" onclick="manage_storage_click($(this),'256Gb');">
                                <span class="storage-name">256 Gb</span>
                            </div>
                                                    </div>
                    </div>
                </div>
                                            </div>
            <div class="border-1 mb-05 mt-15"></div>
            <div class="fdsfs546" style="margin-right: 10px;margin-left: 10px;text-align: center;margin-top: 9px;padding-bottom: 7px;display: flex;">
                <button href="javascript:void(0)" class="apply-btn cancel-btn" onclick="closeNav()">Cancel</button>
                <button href="javascript:void(0)" class="apply-btn filter-apply" onclick="closeNav()">Apply</button>
            </div>
        </div>


        <div class="container-fluid">
        <div class="css-175oi2r" style="padding-right: 16px; padding-left: 16px;">
            <div class="css-175oi2r" style="    margin-top: 5px;">
                <span class="css-1qaijid product-title" style="    color: rgb(0 0 0);font-size: 14px; line-height: 20px; font-weight: 400; font-family: inter_regular; letter-spacing: -0.01px;">
                    <b>Motorola</b> razr 40 Ultra (Glacier Blue, 8GB RAM, 256GB Storage)External AMOLED Display                   
                    
                    </span>   
            </div>
            <div class="css-175oi2r" style="margin-top: 4px;"></div>
        </div>
        <div class="css-175oi2r" style="justify-content: space-between;width: 100%;flex-direction:row;padding-right:16px;padding-left:16px;align-items:center;justify-content:space-between;flex-wrap:wrap;margin: 5px 0px;">
            <div class="css-175oi2r">
                <div class="css-175oi2r" style="flex-direction:row;align-items:center;justify-content:flex-start">
                    <div class="css-175oi2r">
                        <div class="css-175oi2r">
                            <div class="css-175oi2r" style="flex-direction:row;margin-right:4px">
                                <div class="rating-box" style="padding:0">
                                    <div class="jkfjh48">
                                        <div class="5gs5hhg">
                                            <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                        </div>
                                    </div>
                                </div>
                                <div class="css-175oi2r r-6koalj r-18u37iz r-1awozwy">
                                    <div class="css-175oi2r">
                                        <div dir="auto" class="css-1rynq56" style="display: flex;color:rgba(17,17,18,1.00);vertical-align:middle;align-self:center;margin-left:4px">
                                            <span class="css-1qaijidf r-dnmrzs r-1udh08x r-1udbk01 r-3s2u2q r-1iln25a" style="color:rgba(42,85,229,1.00);font-size:12px;line-height:18px;font-weight:600;font-family:inter_semi_bold;letter-spacing:0px;margin-left:4px;margin-right:4px"> Very Good  • </span>
                                            <span class="css-1qaijid r-dnmrzs r-1udh08x r-1udbk01 r-3s2u2q r-1iln25a" style="color:rgba(42,85,229,1.00);font-size:12px;line-height:18px;font-weight:400;font-family:inter_regular;letter-spacing:0px;margin-left:6px">7097 ratings</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div style="display:flex;position:relative;width:58px;height:17px;margin-top: -2px;    margin-left: 10px;">
                <img src="images/SwOvZ3r.png">
            </div>
        </div>
    </div>
        <div class="">
            <div class="css-175oi2r">
                <div class="css-175oi2r" style="margin-right: 16px; margin-left: 16px;">
                    <div class="css-175oi2r">
                        <div class="css-175oi2r" style="flex: 1 1 0%; flex-flow: wrap; margin-top: 8px; align-self: flex-start; margin-bottom: -8px;">
                            <div class="css-175oi2r r-5oul0u r-dnmrzs r-a5pmau r-6koalj r-18u37iz fdgdfg6456">
                                <div class="css-175oi2r r-18u37iz r-1awozwy r-1w6e6rj" style="padding: 6px 4px 6px; border-radius: 2px; background-color: rgb(16, 137, 52);">
                                    <div dir="auto" class="css-1rynq56"><span class="css-1qaijid" style="background-color: rgba(0, 0, 0, 0); color: rgb(255, 255, 255); font-size: 12px; font-family: Roboto; line-height: 16px; text-align: left; font-style: normal;">Saver Deal</span></div>
                                </div>
                                <div class="css-175oi2r" style="height: 0px; width: 0px; border-bottom: 25px solid rgb(16, 137, 52); border-right: 12.5px solid rgba(0, 0, 0, 0); border-top-style: solid; border-left-style: solid;"></div>
                            </div>
                        </div>
                        <div class="css-175oi2r" style="margin: 11px 0px 0 0;">
                            <div class="product-price d-flex my-2">
                                <span class="discount fbbg46454">98% off</span>
                                <span class="mrp fsdfd54" data-mrp="41999">₹41,999</span>
                                <span class="price dfgee5646" data-price="689">₹689</span>
                            </div> 
                        </div>
                    </div>
                    <div class="css-175oi2r" style="flex-direction: row; align-items: center;">
                        Free delivery by 26 Sep                    </div>
                </div>
            </div>
        </div>
        <div class="border-1 mt-10 mb-05"></div>
        <div class="jhhfghJG76" style="margin-right: 16px; margin-left: 16px;">
            <div class="gsfdfgh">
                <div class="">
                    <div style="display: flex; position: relative; width: 24px; height: 24px;">
                        <img src="images/df850a95-675e-479f-aa51-77c863fb682d.webp" style="    padding: 0;width: 100%; height: 100%; margin: auto; object-fit: contain; opacity: 1;">
                    </div>
                </div>
                <div class="css-175oi2r" style="flex-direction: column; flex: 1 1 0%; align-items: flex-start; justify-content: flex-start; margin-left: 16px; margin-top: 4px;">
                    <div class="">
                        <div dir="auto" class="css-1rynq56" style="color: rgb(0, 140, 0); font-size: 14px; line-height: 20px; font-weight: 600;     font-family: Roboto, Helvetica, Arial, sans-serif !important; letter-spacing: -0.01px; flex-wrap: wrap;">FREE Delivery </div>
                        <div dir="auto" class="css-1rynq56" style="color: rgb(17, 17, 18);"><span class="css-1qaijid" style="color: rgb(113, 116, 120); font-size: 14px; line-height: 20px; font-weight: 400; font-family: inter_regular; letter-spacing: -0.01px; flex-wrap: wrap; text-decoration-line: line-through;">₹40</span><span class="css-1qaijid" style="color: rgb(17, 17, 18);"></span></div>
                        <div dir="auto" class="css-1rynq56" style="color: rgb(0, 0, 0); font-size: 14px; line-height: 20px; font-weight: 400; font-family: inter_regular; letter-spacing: -0.01px;"> • </div>
                        <div dir="auto" class="css-1rynq56" style="color: rgb(17, 17, 18); flex-wrap: wrap; align-items: flex-end; font-size: 14px; line-height: 20px; font-weight: 600;     font-family: Roboto, Helvetica, Arial, sans-serif !important; letter-spacing: -0.01px;">Delivery by </div>
                
                    </div>
                    <div class="">
                        <div dir="auto" class="css-1rynq56" style="color: rgb(17, 17, 18); font-size: 14px; line-height: 20px; font-weight: 600;     font-family: Roboto, Helvetica, Arial, sans-serif !important; letter-spacing: -0.01px; padding-bottom: 4px; align-items: center;">26 Sep, Thursday</div>
                    </div>
                </div>
                <div class="">
                <svg width="14" height="14" fill="none" viewBox="0 0 17 17"><path d="m6.627 3.749 5 5-5 5" stroke="#111112" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                </div>
            </div>
        </div>
        <div class="border-3 mt-05 mb-05"></div>
        <div class="jhhfghJG76" style="margin-right: 16px; margin-left: 16px;">
           <div class="container-fluid px-2 py-3 d-flex feature-container product-extra card">
                <div class="col-4 featured-item d-flex align-items-center flex-column bd-highlight px-1">
                  <img class="featured-img mb-3" src="images/7day.webp">
                  <span class="feature-title"> 7 days Replacement </span>
                </div>
                <div class="col-4 featured-item d-flex align-items-center flex-column bd-highlight px-1">
                   <img class="featured-img mb-3" src="images/cod.webp">
                   <span class="feature-title"> No Cash On Delivery </span>
                </div>
                <div class="col-4 featured-item d-flex align-items-center flex-column bd-highlight px-1">
                    <img class="featured-img mb-3 mt-1" src="images/assure.webp">
                    <span class="feature-title"> Plus (F-Assured) </span>
                </div>
            </div>
        </div>

        <div class="border-3 mt-05 mb-05"></div>

        <div class="container-fluid p-0">
            <div class="css-175oi2r" style="flex: 1 1 0%; padding: 12px 16px; flex-flow: wrap; align-items: center;justify-content: space-between;width: 100%;">
                <div class="css-175oi2r" style="flex: 1 1 0%; flex-direction: column;">
                   <div dir="auto" class="css-1rynq56" style="color: rgb(32, 34, 36); font-size: 17px; line-height: 24px; font-weight: 600; font-family: Roboto, Helvetica, Arial, sans-serif !important; letter-spacing: -0.01px;">Highlights</div>
                </div>
                <div class="css-175oi2r">
                   <div data-observerid-731ddd74-25c3-4432-93fd-42236b363750="dc652ffe-f938-4f56-85e4-629f8088e0fb" style="height: 100%; width: 100%;">
                        <div class="css-175oi2r" style="flex-direction: row; padding: 8px 16px; margin-left: 16px; border-width: 1px; border-radius: 2px; align-self: center; align-items: center; border-color: rgb(213, 215, 219);">
                            <svg width="16" height="16" fill="none" viewBox="0 0 16 16"><path d="M7.312 12.625a4.812 4.812 0 1 0 0-9.625 4.812 4.812 0 0 0 0 9.625ZM10.716 11.215 13.5 14" stroke="#2A55E5" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                            <div dir="auto" class="css-1rynq56" style="color: rgb(42, 85, 229); margin-left: 8px; font-size: 14px; line-height: 20px; font-weight: 600; font-family: Roboto, Helvetica, Arial, sans-serif !important; letter-spacing: -0.01px;"> Search </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="product-details">
                <div id="productOverview_feature_div" class="celwidget" data-feature-name="productOverview" data-csa-c-type="widget" data-csa-c-content-id="productOverview" data-csa-c-slot-id="productOverview_feature_div" data-csa-c-asin="B0C7QCHGLF" data-csa-c-is-in-initial-active-row="false" data-cel-widget="productOverview_feature_div" data-csa-c-id="56o3ul-39g1i-cctv26-1z8l7d" amazon="" ember",="" arial,="" sans-serif;="" font-size:="" 14px;"="" style="color: rgb(15, 17, 17);"><div class="a-section a-spacing-small a-spacing-top-small" style="margin-bottom: 0px; margin-top: 8px !important;"><table class="a-normal a-spacing-micro" style="width: 403.672px; margin-bottom: 0px !important;"><tbody><tr class="a-spacing-small po-brand" style="margin-bottom: 8px !important;"><td class="a-span3" style="vertical-align: top; padding: 0px 3px 3px 0px; margin-right: 0px; width: 105.68px; float: none !important;"><span class="a-size-base a-text-bold" style="color: rgb(91, 110, 136); margin-bottom: 0px; font-weight: 700 !important; line-height: 20px !important;">Brand</span></td><td class="a-span9" style="vertical-align: top; padding: 0px 0px 3px 3px; margin-right: 0px; width: 297.992px; text-align: right !important; float: none !important;"><span class="a-size-base po-break-word" style="color: rgb(91, 110, 136); margin-bottom: 0px; word-break: break-word; line-height: 20px !important;">Motorola</span></td></tr><tr class="a-spacing-small po-model_name" style="margin-bottom: 8px !important;"><td class="a-span3" style="vertical-align: top; padding: 3px 3px 3px 0px; margin-right: 0px; width: 105.68px; float: none !important;"><span class="a-size-base a-text-bold" style="color: rgb(91, 110, 136); margin-bottom: 0px; font-weight: 700 !important; line-height: 20px !important;">Model Name</span></td><td class="a-span9" style="vertical-align: top; padding: 3px 0px 3px 3px; margin-right: 0px; width: 297.992px; text-align: right !important; float: none !important;"><span class="a-size-base po-break-word" style="color: rgb(91, 110, 136); margin-bottom: 0px; word-break: break-word; line-height: 20px !important;">Razr 40 Ultra</span></td></tr><tr class="a-spacing-small po-wireless_provider" style="margin-bottom: 8px !important;"><td class="a-span3" style="vertical-align: top; padding: 3px 3px 3px 0px; margin-right: 0px; width: 105.68px; float: none !important;"><span class="a-size-base a-text-bold" style="color: rgb(91, 110, 136); margin-bottom: 0px; font-weight: 700 !important; line-height: 20px !important;">Network Service Provider</span></td><td class="a-span9" style="vertical-align: top; padding: 3px 0px 3px 3px; margin-right: 0px; width: 297.992px; text-align: right !important; float: none !important;"><span class="a-size-base po-break-word" style="color: rgb(91, 110, 136); margin-bottom: 0px; word-break: break-word; line-height: 20px !important;">Unlocked for All Carriers</span></td></tr><tr class="a-spacing-small po-operating_system" style="margin-bottom: 8px !important;"><td class="a-span3" style="vertical-align: top; padding: 3px 3px 3px 0px; margin-right: 0px; width: 105.68px; float: none !important;"><span class="a-size-base a-text-bold" style="color: rgb(91, 110, 136); margin-bottom: 0px; font-weight: 700 !important; line-height: 20px !important;">Operating System</span></td><td class="a-span9" style="vertical-align: top; padding: 3px 0px 3px 3px; margin-right: 0px; width: 297.992px; text-align: right !important; float: none !important;"><span class="a-size-base po-break-word" style="color: rgb(91, 110, 136); margin-bottom: 0px; word-break: break-word; line-height: 20px !important;">Android 13.0</span></td></tr><tr class="a-spacing-small po-cellular_technology" style="margin-bottom: 8px !important;"><td class="a-span3" style="vertical-align: top; padding: 3px 3px 0px 0px; margin-right: 0px; width: 105.68px; float: none !important;"><span class="a-size-base a-text-bold" style="color: rgb(91, 110, 136); margin-bottom: 0px; font-weight: 700 !important; line-height: 20px !important;">Cellular Technology</span></td><td class="a-span9" style="vertical-align: top; padding: 3px 0px 0px 3px; margin-right: 0px; width: 297.992px; text-align: right !important; float: none !important;"><span class="a-size-base po-break-word" style="color: rgb(91, 110, 136); margin-bottom: 0px; word-break: break-word; line-height: 20px !important;">5G</span></td></tr></tbody></table></div></div><div id="featurebullets_feature_div" class="celwidget" data-feature-name="featurebullets" data-csa-c-type="widget" data-csa-c-content-id="featurebullets" data-csa-c-slot-id="featurebullets_feature_div" data-csa-c-asin="B0C7QCHGLF" data-csa-c-is-in-initial-active-row="false" data-cel-widget="featurebullets_feature_div" data-csa-c-id="octse0-rtpwuu-18ajr-v3xe0a" amazon="" ember",="" arial,="" sans-serif;="" font-size:="" 14px;"="" style="color: rgb(15, 17, 17);"><div id="feature-bullets" class="a-section a-spacing-medium a-spacing-top-small" style="margin-bottom: 0px; margin-top: 8px !important;"><hr style="box-sizing: border-box; margin-top: 0px; margin-bottom: 14px; border-top-color: rgb(187, 191, 191); background-color: transparent; line-height: 19px;"><h1 class="a-size-base-plus a-text-bold" style="margin-top: 0px; margin-bottom: 0px; color: rgb(52, 73, 94); padding-bottom: 4px; text-rendering: optimizelegibility; font-weight: 700 !important; line-height: 24px !important; font-size: 16px !important;">About this item</h1><ul class="a-unordered-list a-vertical a-spacing-mini" style="margin-right: 0px; margin-bottom: 0px; margin-left: 18px; padding: 0px; list-style: none;"><li class="a-spacing-mini" style="color: rgb(91, 110, 136); margin: 0px; font-size: 0.875rem; list-style: disc; overflow-wrap: break-word;"><span class="a-list-item" style="color: rgb(15, 17, 17); margin-bottom: 0px;">Snapdragon 8+ Gen 1 Mobile Platform, 8GB LPDDR5 RAM, 256GB built-in UFS 3.1 Storage</span></li><li class="a-spacing-mini" style="color: rgb(91, 110, 136); margin: 0px; font-size: 0.875rem; list-style: disc; overflow-wrap: break-word;"><span class="a-list-item" style="color: rgb(15, 17, 17); margin-bottom: 0px;">Main display: 6.9"" FHD+ pOLED display External display,3.6"" pOLED display</span></li><li class="a-spacing-mini" style="color: rgb(91, 110, 136); margin: 0px; font-size: 0.875rem; list-style: disc; overflow-wrap: break-word;"><span class="a-list-item" style="color: rgb(15, 17, 17); margin-bottom: 0px;">Display Resolution - Main display: FHD+ (2640 x 1080) | 413ppi , External display: 1066 x 1056 | 413ppi</span></li><li class="a-spacing-mini" style="color: rgb(91, 110, 136); margin: 0px; font-size: 0.875rem; list-style: disc; overflow-wrap: break-word;"><span class="a-list-item" style="color: rgb(15, 17, 17); margin-bottom: 0px;">Main Camera - 12MP (f/1.5, 1.4μm) | OIS, Rear Camera - 13MP (f/2.2, 1.12μm) | Ultra-wide + macro | FOV 108°, Single LED flash</span></li><li class="a-spacing-mini" style="color: rgb(91, 110, 136); margin: 0px; font-size: 0.875rem; list-style: disc; overflow-wrap: break-word;"><span class="a-list-item" style="color: rgb(15, 17, 17); margin-bottom: 0px;">Front Camera - Main display 32MP (f/2.4, 0.7 μm) | 8MP (f/2.4, 1.4um) Quad Pixel External display Main: 12MP (f/1.5, 1.4μm) | OIS Wide: 13MP (f/2.2, 1.12μm) | FOV 108°</span></li><li class="a-spacing-mini" style="color: rgb(91, 110, 136); margin: 0px; font-size: 0.875rem; list-style: disc; overflow-wrap: break-word;"><span class="a-list-item" style="color: rgb(15, 17, 17); margin-bottom: 0px;">Corning Gorilla Glass Victus on both front and rear, IP52 Water-repellent design, Battery -3800mAh non-removable, 30W TurboPower charging support 5W wireless charging support (charger sold separately)</span></li><li class="a-spacing-mini" style="color: rgb(91, 110, 136); margin: 0px; font-size: 0.875rem; list-style: disc; overflow-wrap: break-word;"><span class="a-list-item" style="color: rgb(15, 17, 17); margin-bottom: 0px;">Dual stereo speakers with Dolby Atmos and Spatial Sound Qualcomm Snapdragon Sound</span></li><li class="a-spacing-mini" style="color: rgb(91, 110, 136); margin: 0px; font-size: 0.875rem; list-style: disc; overflow-wrap: break-word;"><span class="a-list-item" style="color: rgb(15, 17, 17); margin-bottom: 0px;">Sensors - Fingerprint reader, Proximity + light sensor, Ambient light sensor, Accelerometer, Gyroscope, eCompass, Hall sensor<br><h2 style="margin-top: 0px; margin-bottom: 0px; font-weight: 700; line-height: 32px; padding-bottom: 4px; text-rendering: optimizelegibility; font-size: 21px !important; color: rgb(51, 51, 51) !important;">From the manufacturer</h2><div class="aplus-v2 desktop celwidget" cel_widget_id="aplus" data-cel-widget="aplus" data-csa-c-id="ac9bid-yl0bmw-mhboyb-w2tpz2" style="margin-left: auto; margin-right: auto;"><div class="celwidget aplus-module 3p-module-b aplus-standard" cel_widget_id="aplus-3p-module-b" data-cel-widget="aplus-3p-module-b" data-csa-c-id="6z44u1-8wolg5-iqu9e4-5yotua"><div class="aplus-module-wrapper aplus-3p-fixed-width" style="width: 970px; margin-left: auto; margin-right: auto;"><img alt="Image 1" src="images/8c1f0a0d-2764-41d9-9e66-9e3e6fe3c751.__CR0%2C0%2C970%2C600_PT0_SX970_V1___.jpg" class="a-spacing-base" data-src="https://m.media-amazon.com/images/S/aplus-media-library-service-media/8c1f0a0d-2764-41d9-9e66-9e3e6fe3c751.__CR0,0,970,600_PT0_SX970_V1___.jpg" style="vertical-align: top; border: 0px; max-width: 100%; height: auto; margin-bottom: 12px !important;"></div></div><div class="celwidget aplus-module 3p-module-b aplus-standard" cel_widget_id="aplus-3p-module-b" data-cel-widget="aplus-3p-module-b" data-csa-c-id="w9rx6i-t1g7bo-uhhan1-1b7da6"><div class="aplus-module-wrapper aplus-3p-fixed-width" style="width: 970px; margin-left: auto; margin-right: auto;"><img alt="Image 2" src="images/bddd6095-3317-4f45-bdd7-a25ae452bad5.__CR0%2C0%2C970%2C600_PT0_SX970_V1___.jpg" class="a-spacing-base" data-src="https://m.media-amazon.com/images/S/aplus-media-library-service-media/bddd6095-3317-4f45-bdd7-a25ae452bad5.__CR0,0,970,600_PT0_SX970_V1___.jpg" style="vertical-align: top; border: 0px; max-width: 100%; height: auto; margin-bottom: 12px !important;"></div></div><div class="celwidget aplus-module 3p-module-b aplus-standard" cel_widget_id="aplus-3p-module-b" data-cel-widget="aplus-3p-module-b" data-csa-c-id="niq0zq-x0jo0e-7z5xmm-87amsx"><div class="aplus-module-wrapper aplus-3p-fixed-width" style="width: 970px; margin-left: auto; margin-right: auto;"><img alt="Image 3" src="images/beb1d0bf-5953-4cee-99a3-2e5bee176319.__CR0%2C0%2C970%2C600_PT0_SX970_V1___.jpg" class="a-spacing-base" data-src="https://m.media-amazon.com/images/S/aplus-media-library-service-media/beb1d0bf-5953-4cee-99a3-2e5bee176319.__CR0,0,970,600_PT0_SX970_V1___.jpg" style="vertical-align: top; border: 0px; max-width: 100%; height: auto; margin-bottom: 12px !important;"></div></div><div class="celwidget aplus-module 3p-module-b aplus-standard" cel_widget_id="aplus-3p-module-b" data-cel-widget="aplus-3p-module-b" data-csa-c-id="wc0yju-lho43c-dbgic5-2jhivt"><div class="aplus-module-wrapper aplus-3p-fixed-width" style="width: 970px; margin-left: auto; margin-right: auto;"><img alt="Image 4" src="images/d499b828-a1b7-46ea-adf4-c29932bdfe7f.__CR0%2C0%2C970%2C600_PT0_SX970_V1___.jpg" class="a-spacing-base" data-src="https://m.media-amazon.com/images/S/aplus-media-library-service-media/d499b828-a1b7-46ea-adf4-c29932bdfe7f.__CR0,0,970,600_PT0_SX970_V1___.jpg" style="vertical-align: top; border: 0px; max-width: 100%; height: auto; margin-bottom: 12px !important;"></div></div><div class="celwidget aplus-module 3p-module-b aplus-standard" cel_widget_id="aplus-3p-module-b" data-cel-widget="aplus-3p-module-b" data-csa-c-id="amefwh-fcud3l-8cwi5f-a1lmho"></div></div></span></li><li class="a-spacing-mini" style="color: rgb(91, 110, 136); margin: 0px; font-size: 0.875rem; list-style: disc; overflow-wrap: break-word;"><br style="font-family: Montserrat, sans-serif; font-size: 14px;"></li></ul></div></div>                            </div>
        </div>
        <div class="button-container flex">
                    <button class="buynow-button buynow-button-white product-page-buy add_cart" onclick="buyNow(title='Motorola razr 40 Ultra (Glacier Blue, 8GB RAM, 256GB Storage)External AMOLED Display',price='689.00',mrp='41999.00',image='https://m.media-amazon.com/images/I/617WN7I3E4L._SX679_.jpg');">
            Add to Cart
        </button>
        <button class=" buynow-button product-page-buy buy_now" onclick="buyNow(title='Motorola razr 40 Ultra (Glacier Blue, 8GB RAM, 256GB Storage)External AMOLED Display',price='689.00',mrp='41999.00',image='https://m.media-amazon.com/images/I/617WN7I3E4L._SX679_.jpg');">
            Buy Now
        </button>
                </div>
        <div class="border-3 mt-05 mb-05"></div>

        <div class="container-fluid p-0" style="margin-bottom:60px">
            <div class="css-175oi2r" style="flex: 1 1 0%; padding: 12px 16px; flex-flow: wrap; align-items: center;justify-content: space-between;width: 100%;">
                <div class="css-175oi2r" style="flex: 1 1 0%; flex-direction: column;">
                   <div dir="auto" class="css-1rynq56" style="color: rgb(32, 34, 36); font-size: 17px; line-height: 24px; font-weight: 600; font-family: Roboto, Helvetica, Arial, sans-serif !important; letter-spacing: -0.01px;">Similar Products</div>
                </div>
                <div class="css-175oi2r">
                   <div data-observerid-731ddd74-25c3-4432-93fd-42236b363750="dc652ffe-f938-4f56-85e4-629f8088e0fb" style="height: 100%; width: 100%;">
                        <div class="css-175oi2r" style="flex-direction: row; padding: 8px 16px; margin-left: 16px; border-width: 1px; border-radius: 2px; align-self: center; align-items: center; border-color: rgb(213, 215, 219);">
                            <svg width="16" height="16" fill="none" viewBox="0 0 16 16"><path d="M7.312 12.625a4.812 4.812 0 1 0 0-9.625 4.812 4.812 0 0 0 0 9.625ZM10.716 11.215 13.5 14" stroke="#2A55E5" stroke-width="1.2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
                            <div dir="auto" class="css-1rynq56" style="color: rgb(42, 85, 229); margin-left: 8px; font-size: 14px; line-height: 20px; font-weight: 600; font-family: Roboto, Helvetica, Arial, sans-serif !important; letter-spacing: -0.01px;"> Search </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="related-product">
            <div class="products" id="products"> 
                <div class="product-list">
                
                                    <a href="iphone-16.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/-original-imah4jz64htqmsxg.jpeg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> iPhone 15 Pro Max 512 GB                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹164,900</span>
                                <span class="sell-price">₹1600</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 25 Sep</span>
                            </div>
                        </div>
                    </a>  
                
                
                
                                        <a href="iphone.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/apple-iphone-14-pro-max-256-gb-deep-purple-6-gb-ram-.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> iPhone 14 Pro Max 256 GB                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹136,000</span>
                                <span class="sell-price">₹998</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="samsung-galaxy.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/81vxWpPpgNL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Samsung</span> Galaxy S24 Ultra 5G AI Smartphone (Titanium Gray, 12GB, 512GB Storage)                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹139,000</span>
                                <span class="sell-price">₹989</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="iphone-15.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71zFRCcMS2L._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> iPhone 15 Plus (128 GB)                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹89,000</span>
                                <span class="sell-price">₹896</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 26 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="samsung.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/samsung-galaxy-z-fold-4-256-gb-beige-12-gb-ram-.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Samsung</span> Galaxy Z Fold 4 256 GB (Beige, 12 GB RAM)                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹146,000</span>
                                <span class="sell-price">₹969</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="vivo-v27.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71waR9n2enL._SX522_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">VIVO</span> V27 5G (Magic Blue, 128 GB) (8 GB RAM)                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">97% off</span>
                                <span class="mrp-price line-through">₹25,999</span>
                                <span class="sell-price">₹698</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="realme.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/81GNHx0grQL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Realme</span> 12 Pro+ 5G Submarine Blue, 12GB RAM, 256GB Storage                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">97% off</span>
                                <span class="mrp-price line-through">₹31,999</span>
                                <span class="sell-price">₹697</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="redmi.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/7b66930168d5b7b3c3d0cce70322e77b!400x400!85.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Redmi</span> Note 13 Pro+ 5G                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹35,999</span>
                                <span class="sell-price">₹669</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="dell.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71mBe9xEEdL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Dell</span> Inspiron 7441 Plus Laptop Built in AI Snapdragon X Plus X1P 64 100 16GB LPDDR5X  512GB SSD  Qualcomm GPU 14                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹111,990</span>
                                <span class="sell-price">₹959</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="apple-2024.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71ItMeqpN3L._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> 2024 MacBook Air  Laptop with M3 chip(13.6) Liquid Retina Display, 8GB Unified Memory, 256GB SSD Storage                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹130,000</span>
                                <span class="sell-price">₹950</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="hp-laptop.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71wMYNf8MZL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">HP</span> Laptop 15s, AMD Ryzen 3 5300U, 15.6-inch FHD, 8GB DDR4, 512GB                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹31,999</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="samsung-633.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/61QKzOZbl8L._SY741_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Samsung</span> 633 L 3 Star  Frost Free  Double Door  Convertible 5 in 1 Digital Inverter Side By Side Refrigerator with AI  WiFi &amp; Water &amp; Ice Dispenser RS78CG8543S9HL Silver Refined Inox 2024 Model                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹111,490</span>
                                <span class="sell-price">₹790</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 26 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="lg.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/61Z%2BPDXEJkL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">LG</span> 833 L Frost Free Smart Inverter Compressor Wi Fi Side By Side 5 Star Appliance G c B307Ssvl  Noble Steel2 Door Cooling Hygiene Fresh                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹94,990</span>
                                <span class="sell-price">₹790</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="panasonic.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71hnes2pyTL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Panasonic</span> 1.5 Ton 5 Star Wi Fi Inverter Smart Split AC Copper 7 in 1 Convertible with additional AI Mode 4 Way Swing  X Air Purification Technology  CS CU HU18ZKYF 2023 Model White                             </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹54,999</span>
                                <span class="sell-price">₹789</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="daikin.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71KsH42yyTL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Daikin</span> 1.8 Ton 3 Star Hot Cold Inverter Split AC Copper PM 2.5 Filter FTHT60UV White                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹62,990</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 26 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="sony.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71j3bPnm%2BUL._SX522_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Sony</span> Alpha ILCE 7M3K Full Frame 24.2MP Mirrorless Digital SLR Camera with 28 70mm Zoom Lens  4K Full Frame  Real Time Eye Auto Focus LCD Low Light Camera   Black                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹139,000</span>
                                <span class="sell-price">₹650</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="nikon.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/81WtQ64-SOL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Nikon</span> D850 45.7MP Digital SLR Camera (Black) with AF-S Nikkor 24-120mm F4G ED VR Lens and 64GB Memory Card                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹129,000</span>
                                <span class="sell-price">₹650</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="ifb.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/61F9bBjEuUL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">IFB</span> Laundrimagic 3-in-1 8.5 Kg/6.5 Kg/2.5 Kg Inverter Washer Dryer Refresh (Executive ZXM, Mocha)                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹58,490</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="ifb1.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/-original-imaghuqxmy3bhzds.jpeg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">IFB</span> 6 Kg 5 Star AI Powered Fully Automatic Front Load Washing Machine                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">97% off</span>
                                <span class="mrp-price line-through">₹22,999</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 26 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="symphony.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/51Q5OzAoS0L._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Symphony</span> Touch 35 Personal Air Cooler For Home with Honeycomb Pads, Powerful Blower, i-Pure Technology and Cool Flow Dispenser (35L, White)                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">94% off</span>
                                <span class="mrp-price line-through">₹10,999</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 26 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="crompton.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/51E-OaCxahL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Crompton</span> Optimus Desert Air Cooler- 100L with 18 Fan, Everlast Pump, Large  Easy Clean Ice Chamber, Humidity Control White                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">95% off</span>
                                <span class="mrp-price line-through">₹13,999</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 26 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="apple-airpods.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/61sRKTAfrhL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> AirPods Pro (2nd Generation) with MagSafe Case(White)                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">97% off</span>
                                <span class="mrp-price line-through">₹21,999</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="oneplus-buds.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/MP000000018527675_658Wx734H_202308011615031.jpeg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">ONEPLUS</span> Buds Pro 2R BT with Adaptive Noise Cancellation Earbuds (Misty White)                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">95% off</span>
                                <span class="mrp-price line-through">₹9,999</span>
                                <span class="sell-price">₹489</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="apple-watch.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/91v9yAPw3-L._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> Watch Ultra GPS  Cellular 49 mm smart watch wRugged Titanium Case Starlight Alpine Loop Small Fitness Tracker                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹88,000</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 26 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="zebronics.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71r-bf42LqL._SX522_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Zebronics</span> Juke bar 9550 pro 5.2 Soundbar (625 Watts)Dolby Audio                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">94% off</span>
                                <span class="mrp-price line-through">₹9,999</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 26 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="boat.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71WFi0rx5PL._SX522_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">boAt</span> Aavante Bar 5400D with 550W Dolby Audio 5.1 Channel with wireless subwoofer                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">95% off</span>
                                <span class="mrp-price line-through">₹11,899</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="powermax.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/513XijizZOL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">PowerMax</span> Fitness TD-A1 Motorised Foldable Treadmill for Home User Wt. 100kg 15 Lvl Auto-Incline Running Machine                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">95% off</span>
                                <span class="mrp-price line-through">₹16,999</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                      
                </div>
            </div>
            </div>
        </div>
    
    
    

<script type="text/javascript">
    BASEURL = "";
    function manage_color_click(that, color, keys, color_id, all_images) {
        $(".show_color").html(color);
        $(".color-item").removeClass('active');
        that.addClass("active");
        var images = all_images.split(',');
        var active_color = 0;
        images.forEach(function(image_url, i) {
            if (image_url != "") {
                c_index = i + 1;
                $(".slider-item-" + c_index).attr('src', image_url);
            }
        });
        $(".main_image  ").addClass('active');

        if ($(".storage-item.active").length == 0) {
            $(".mrp").text("₹" + that.attr("data-mrp")).attr("data-mrp", that.attr("data-mrp"));
            $(".price").text("₹" + that.attr("data-selling-price")).attr("data-price", that.attr("data-selling-price"));
        }
    }
function add_to_cart(CartEvent = "") {

    products = [];
    if (localStorage.getItem('products')) {
        products = JSON.parse(localStorage.getItem('products'));
    }

    price = parseInt($('.price').attr("data-price"));
    mrp_price = parseInt($('.mrp').attr("data-mrp"));
    product_id = $('.product-title').attr("data-id");
    product_title = $('.product-title').html();
    discount_percentage = $('.discount').html();
    discount_amount = (mrp_price - price);
    product_img = $('.main_image').attr('src');
    color = $('.color-item.active').find('span').text();
    size = $('.dress-size.active').find('span').text();
    storage = $('.storage-item.active').find('span').text();

    is_added_product = 0;
    is_buyNew_product = 0;
    if (products.length > 0) {
        for (index = 0; index < products.length; index++) {
            products[index]['index'] = index;
            if (products[index]['product_id'] == product_id && products[index]['color'] == color && products[index]['size'] == size) {
                if (CartEvent != "buyNow") {
                    products[index]['qty'] = products[index]['qty'] + 1;
                }
                is_added_product = 1;
                break;
            }
        }
    }
    if (!is_added_product) {
        products.push({
            'index': products.length,
            'product_id': product_id,
            'product_title': product_title,
            'discount_percentage': discount_percentage,
            'discount_amount': discount_amount,
            'product_img': product_img,
            'color': color,
            'size': size,
            'storage': storage,
            'mrp': mrp_price,
            'price': price,
            "qty": 1
        });
    }

    localStorage.setItem('products', JSON.stringify(products));
    CartList();
    if (CartEvent == "buyNow") {
        window.location.href = BASEURL + "address.php";
    } else {
        window.location.href = BASEURL + "address.php";
        
    }
}


    function manage_storage_click(that, class_name) {
        
        $(".show_storage").html(class_name);
        $(".storage-item").removeClass("active");
        $("." + class_name).addClass("active");
        $(".mrp").text("₹" + that.attr("data-mrp")).attr("data-mrp", that.attr("data-mrp"));
        $(".price").text("₹" + that.attr("data-selling-price")).attr("data-price", that.attr("data-selling-price"));
    }


</script>                
                
                
                
                
                

               
                
                

                <script src="js/bootstrap.min.js"></script>
                <script src="js/jquery.lazyload.min.js"></script>
                
                <script>
                    $(window).ready(function() {
                        $(".itivvW").remove();
                    });
                    //  Cart Start ==================
                    $(".custom_lazyload")
                        .lazyload({
                            effect: "fadeIn",
                            threshold: 5000,
                        })
                        .removeClass("custom_lazyload");

                    function openNav() {
                        $("body").addClass("shade");
                        document.getElementById("mySidenav").style.right = "0";
                        document.getElementById("overlay").style.display = "block";
                    }

                    function closeNav() {
                        $("body").removeClass("shade");
                        document.getElementById("mySidenav").style.right = "-100%";
                        document.getElementById("overlay").style.display = "none";
                    }

                    function CartList() {
                        cart_html = "";
                        products = [];
                        cartTotalAmount = 0;

                        if (localStorage.getItem('products')) {
                            products = JSON.parse(localStorage.getItem('products'));
                        }
                        if (products.length > 0) {
                            for (index = 0; index < products.length; index++) {

                                qty = products[index]['qty'];
                                cartTotalAmount += (products[index]['price'] * qty);

                                product_qty = qty < 10 ? "0" + qty : qty;
                                cart_html += '<div class="cart-product cart-product-index-' + products[index]['index'] + '">\
                                    <div class="cart-product-img">\
                                            <img src="' + products[index]['product_img'] + '" alt="">\
                                        </div>\
                                        <div class="cart-product-details">\
                                            <div class="cart-product-title">\
                                                <p>' + products[index]['product_title'] + '</p>\
                                                <img src="https://cdn.shopify.com/s/files/1/0057/8938/4802/files/Group_1_93145e45-8530-46aa-9fb8-6768cc3d80d2.png?v=1633783107" class="remove-cart-item" data-index="' + products[index]['index'] + '" alt="">\
                                            </div>\
                                            <div class="cart-product-pricing">\
                                                <p class="cart-product-price">₹' + products[index]['price'] + '</p> \
                                                <span class="cart-product-mrp">₹' + products[index]['mrp'] + '</span>\
                                            </div>\
                                                <div class="cart-product-description">\
                                                <p class="cart-product-size">Color :' + products[index]['color'] + '</p>\
                                                </div>\
                                            <div class="cart-product-description">\
                                                <p class="cart-product-size">Size/Storage :' + products[index]['storage'] + '</p>\
                                                <span class="sc-lbxAil evmCQI"></span>\
                                                \
                                                    <div class="cart-qty-wrapper">\
                                                        <span class="minus" data-index="' + products[index]['index'] + '">-</span>\
                                                        <span class="num">' + product_qty + '</span>\
                                                        <span class="plus" data-index="' + products[index]['index'] + '">+</span>\
                                                    </div>\
                                                \
                                            </div>\
                                        </div>\
                                    </div>';
                            }
                        }
                        if (cart_html == "") {
                            cart_html = ' <center style="margin-top: 25vh;margin-bottom:30vh">\
                               <svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="110" height="110" x="0" y="0" viewBox="0 0 450.391 450.391" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g><path d="M143.673 350.322c-25.969 0-47.02 21.052-47.02 47.02 0 25.969 21.052 47.02 47.02 47.02 25.969 0 47.02-21.052 47.02-47.02.001-25.968-21.051-47.02-47.02-47.02zm0 73.143c-14.427 0-26.122-11.695-26.122-26.122s11.695-26.122 26.122-26.122 26.122 11.695 26.122 26.122c.001 14.427-11.695 26.122-26.122 26.122zM342.204 350.322c-25.969 0-47.02 21.052-47.02 47.02 0 25.969 21.052 47.02 47.02 47.02s47.02-21.052 47.02-47.02c0-25.968-21.051-47.02-47.02-47.02zm0 73.143c-14.427 0-26.122-11.695-26.122-26.122s11.695-26.122 26.122-26.122 26.122 11.695 26.122 26.122c.001 14.427-11.695 26.122-26.122 26.122zM448.261 76.037a13.064 13.064 0 0 0-8.359-4.18L99.788 67.155 90.384 38.42C83.759 19.211 65.771 6.243 45.453 6.028H10.449C4.678 6.028 0 10.706 0 16.477s4.678 10.449 10.449 10.449h35.004a27.17 27.17 0 0 1 25.078 18.286l66.351 200.098-5.224 12.016a50.154 50.154 0 0 0 4.702 45.453 48.588 48.588 0 0 0 39.184 21.943h203.233c5.771 0 10.449-4.678 10.449-10.449s-4.678-10.449-10.449-10.449H175.543a26.646 26.646 0 0 1-21.943-12.539 28.733 28.733 0 0 1-2.612-25.078l4.18-9.404 219.951-22.988c24.16-2.661 44.034-20.233 49.633-43.886L449.83 84.917a8.882 8.882 0 0 0-1.569-8.88zm-43.885 109.191c-3.392 15.226-16.319 26.457-31.869 27.69l-217.339 22.465-48.588-147.33 320.261 4.702-22.465 92.473z" fill="#cccccc" opacity="1" data-original="#cccccc" class=""></path></g></svg>\
                                    <p style="font-size: 20px;font-weight: 600;color: #1a2024;margin-top:3rem;margin-bottom: 40px;">Your cart is feeling lonely</p>\
                                    <div class="button-wrapper">\
                                    <!-- <a href="#" class="btn btn-dark" style="border-radius: 10px!important;font-size: 16px;background-image: none;color: #fff;text-transform: capitalize;padding: 10px 16px;" onclick="closeNav()">Start shopping</a> --> </div></center>';
                        }

                        $(".cart-products-list").html(cart_html);

                        if (cartTotalAmount > 0) {
                            $(".cart__footer").show();
                            $(".cartTotalAmount").html("₹" + cartTotalAmount.toFixed(2));

                        } else {
                            $(".cart__footer").hide();
                        }
                        localStorage.setItem('cartTotalAmount', cartTotalAmount.toFixed(2));

                        //  Cart FFloating Item
                        $(".header__cart-count--floating").html(products.length);
                        if (products.length > 0) {
                            $(".header__cart-count--floating").removeClass("d-none");
                        } else {
                            $(".header__cart-count--floating").addClass("d-none");
                            if ("cart" == "product_details" || "payment" == "product_details") {
                                window.location.href = "index.php";
                            }
                        }
                    }
                    CartList();

                    function removeCart(removeIndex) {
                        CartProducts = [];

                        if (localStorage.getItem('products')) {
                            CartProducts = JSON.parse(localStorage.getItem('products'));
                        }

                        CartProducts.splice(removeIndex, 1);
                        $(".cart-product-index-" + removeIndex).remove();

                        for (index = 0; index < CartProducts.length; index++) {
                            CartProducts[index]['index'] = index;
                        }

                        localStorage.setItem('products', JSON.stringify(CartProducts));
                        CartList();
                    }

                    function updateCartQty(Index, newQty) {
                        CartProducts = [];

                        if (localStorage.getItem('products')) {
                            CartProducts = JSON.parse(localStorage.getItem('products'));
                        }

                        for (let index = 0; index < CartProducts.length; index++) {
                            if (CartProducts[index]['index'] == Index) {
                                CartProducts[index]['qty'] = newQty;
                            }
                        }
                        localStorage.setItem('products', JSON.stringify(CartProducts));
                        CartList();
                    }

                    // Qty Add Minus start ===========
                    $(document).ready(function() {
                        // Cache jQuery selectors for performance
                        const $plusButton = $(".plus");
                        const $minusButton = $(".minus");
                        const $numberDisplay = $(".num");

                        // Initialize the counter

                        // Function to update the display and handle formatting
                        const updateDisplay = (that) => {
                            const formattedCount = count < 10 ? "0" + count : count;
                            that.text(formattedCount);
                        };

                        // Event listener for the plus button
                        $(document).on("click", ".plus", function() {
                            product_index = $(this).attr("data-index");
                            $that = $(this).parent(".cart-qty-wrapper").find(".num");
                            count = parseInt($that.text());
                            count++;
                            updateDisplay($that);
                            updateCartQty(product_index, count);
                        });

                        // Event listener for the minus button
                        $(document).on("click", ".minus", function() {
                            product_index = $(this).attr("data-index");
                            $that = $(this).parent(".cart-qty-wrapper").find(".num");
                            count = parseInt($that.text());
                            if (count > 1) {
                                count--;
                                updateDisplay($that);
                                updateCartQty(product_index, count);
                            } else {
                                removeCart(product_index);
                            }
                        });


                        $(document).on("click", ".remove-cart-item", function() {
                            product_index = $(this).attr("data-index");
                            removeCart(product_index);
                        });
                    });

                    // Qty Add Minus End ===========
                    //  Cart End  ==========================

                    $("#back-btn").on("click", function() {
                        history.back();
                    });
                </script>
                <script>
            $(document).ready(function() {
                var hours = parseInt(localStorage.getItem('timerHours')) || 0;
                var minutes = parseInt(localStorage.getItem('timerMinutes')) || 11;
                var seconds = parseInt(localStorage.getItem('timerSeconds')) || 0;

                function countdown() {
                    var interval = setInterval(function() {
                        if (seconds > 0) {
                            seconds--;
                        } else {
                            if (minutes > 0) {
                                minutes--;
                                seconds = 59;
                            } else {
                                if (hours > 0) {
                                    hours--;
                                    minutes = 59;
                                    seconds = 59;
                                } else {
                                    clearInterval(interval);
                                    // alert('Countdown finished!');
                                }
                            }
                        }

                        // Store timer state in localStorage
                        localStorage.setItem('timerHours', hours);
                        localStorage.setItem('timerMinutes', minutes);
                        localStorage.setItem('timerSeconds', seconds);

                        // Format numbers to always have 2 digits
                        var formattedHours = String(hours).padStart(2, '0');
                        var formattedMinutes = String(minutes).padStart(2, '0');
                        var formattedSeconds = String(seconds).padStart(2, '0');

                        // Update the countdown display
                        $(".jFYRpH").html(formattedMinutes + "min : " + formattedSeconds + "sec");
                        // $(".js-timer-hours").text(formattedHours);
                        // $(".js-timer-minutes").text(formattedMinutes);
                        // $(".js-timer-seconds").text(formattedSeconds);
                    }, 1000); // Update every 1000 milliseconds (1 second)
                }

                // Initial call
                countdown();
            })
        </script>
                <style>
                    .steps.svelte-idjy9v .steps-inner .step.active .info-wrap .circle-box.svelte-idjy9v {
                        border-color: #000000;
                        color: #000000;
                        background: #fff;
                    }


                    .steps.svelte-idjy9v .steps-inner .step.active .info-wrap .title.svelte-idjy9v {
                        color: #000000;
                    }

                    .steps.svelte-idjy9v .steps-inner .step.svelte-idjy9v:last-child {
                        justify-content: center;
                    }

                    .steps.svelte-idjy9v.svelte-idjy9v {
                        padding: 2.3rem 1.2rem 0.5rem;

                    }

                    ._2dxSCm .search-div:before {
                        background: url('search.html');
                    }
                </style>
                
                
    <script src="js/main.js"></script> 
        <script defer="" src="js/manage_product.js"></script>

</body></html>