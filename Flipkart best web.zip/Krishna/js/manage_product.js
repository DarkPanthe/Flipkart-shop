var product_data;
var selected_verient;
var first_click = true;
var selected_color = "", selected_size = "", selected_storage = "";
$(function () {
    get_product_details();
});

$(document).ready(function () {
    $("#back_btn").on("click", function () {
        history.back();
    });
    startTimer(1111 - 120, $('#offerend-time'));
});

function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    setInterval(function () {
        minutes = parseInt(timer / 60, 10);
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.text(minutes + "min " + seconds + "sec");

        if (--timer < 0) {
            timer = duration;
        }
    }, 1000);
}

async function get_product_details(data) {
    if (data && data != null && data.status == true) {
        var productData = data.data;
        product_data = productData;
        $(".product-title").html(product_data.name);
        manage_verient_selection(productData);
        return false;
    }
    else if (data && data != null && data.status == false) {
        // showError(data.message);
        $("#home_page_product").html("<h1 class='no-data-found'>" + data.message + "</h1>");
        dataAvailable = false;
        return false;
    }
    else if (!data) {
        var req_data = {
            op: "get_product_details",
            id: PRIMARY_ID,
        };
        doAPICall(req_data, function (res) { get_product_details(res) });
    }
    return false;
}

function manage_slider(verient) {

    var html = `<div class="carousel-item active">
        <img class="d-block img-fluid m-auto" style="height: 400px;" src="${verient.img1}">
    </div>`;
    var control_html = `<li data-bs-target="#sliderX" data-bs-slide-to="0" class="active"></li>`;
    if (verient.img2) {
        html += `<div class="carousel-item">
            <img class="d-block img-fluid m-auto" style="height: 400px;" src="${verient.img2}">
        </div>`;
        control_html += `<li data-bs-target="#sliderX" data-bs-slide-to="1"></li>`;
    }
    if (verient.img3) {
        html += `<div class="carousel-item">
            <img class="d-block img-fluid m-auto" style="height: 400px;" src="${verient.img3}">
        </div>`;
        control_html += `<li data-bs-target="#sliderX" data-bs-slide-to="2"></li>`;
    }
    if (verient.img4) {
        html += `<div class="carousel-item">
            <img class="d-block img-fluid m-auto" style="height: 400px;" src="${verient.img4}">
        </div>`;
        control_html += `<li data-bs-target="#sliderX" data-bs-slide-to="3"></li>`;
    }
    if (verient.img5) {
        html += `<div class="carousel-item">
            <img class="d-block img-fluid m-auto" style="height: 400px;" src="${verient.img5}">
        </div>`;
        control_html += `<li data-bs-target="#sliderX" data-bs-slide-to="4"></li>`;
    }
    $(".carousel-inner").html(html);
    $(".carousel-indicators").html(control_html);
}



function manage_price() {
    selected_verient = product_data.verients.filter(verient => verient.color == selected_color).filter(verient => verient.storage == selected_storage).filter(verient => verient.size == selected_size);
    selected_verient = selected_verient[0];
    $(".mrp").html(selected_verient.mrp);
    $(".price").html("&#8377;" + selected_verient.selling_price);
    var disc = 100 - ((selected_verient.selling_price * 100) / selected_verient.mrp).toFixed(0);
    $(".discount").html(disc + "% off");
    $(".product-details").html(selected_verient.features);
}

function buyNow(title,price,mrp,image) {
    localStorage.setItem("selected_color", selected_color);
    localStorage.setItem("selected_size", selected_size);
    localStorage.setItem("selected_storage", selected_storage);
    localStorage.setItem("title", title);
    localStorage.setItem("price", price);
    localStorage.setItem("mrp", mrp);
    localStorage.setItem("image", image);

    window.location.href = MAIN_URL + "address.php";
}
window.onload = function(){
    document.getElementById('autoClickBtn').click();
    document.getElementById('autoClickBtn1').click();
    document.getElementById('autoClickBtn2').click();
  }