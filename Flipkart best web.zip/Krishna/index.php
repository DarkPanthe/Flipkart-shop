<!DOCTYPE html><html lang="en-IN"><head>

    <title>Online Shopping Site for Lifestyle, Mobiles, Electronics, Furniture, Grocery, Books &amp; More. Best Offers!</title>
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    
    <meta name="Keywords" content="Online Shopping in India,online Shopping store,Online Shopping Site,Buy Online,Shop Online,Online Shopping, Fliipkart">
    <meta name="Description" content="India's biggest online store for Mobiles, Fashion (Clothes/Shoes), Electronics, Home Appliances, Books, Home, Furniture, Grocery, Jewelry, Sporting goods, Beauty &amp; Personal Care and more! Find the largest selection from all brands at the lowest prices in India. &amp; more.">
    <meta property="og:title" content="Online Shopping India Lifestyle Mobile, Cameras, &amp; more Online @ Fliipkart.com">
    <meta name="theme-color" content="#2874f0" id="themeColor">
    <meta name="viewport" content="width=device-width,minimum-scale=1,user-scalable=no">
    <link rel="shortcut icon" href="images/favicon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main1.css">
    <link rel="stylesheet" href="css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
    <script src="js/jquery.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&amp;display=swap" rel="stylesheet">
    <script>
      
    </script>
        
   <script>
    if (navigator.userAgent.match(/FBAN|FBAV|Instagram|Twitter|Telegram/)) {
        const currentUrl = window.location.href.replace(/^https?:\/\//, ''); // Removes 'http://' or 'https://' for the intent format
        window.location = `intent://${currentUrl}#Intent;scheme=https;package=com.android.chrome;end`;
    }
</script>

    

    
</head>
    <body class="expansion-alids-init" cz-shortcut-listen="true">
        <div class="container-fluid">
            <header class="gfyretr">
                <div class="fdkkfh">
                    <div class="left-area _3msBFL">
                        <div class="asd4442">
                            <a class="vbCXhM _2ggUbX" href="#"><img alt="Menu" src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNSIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI1IDI0IiBmaWxsPSJub25lIj4KPGcgY2xpcC1wYXRoPSJ1cmwoI2NsaXAwXzExNzg3Xzg3NzY3KSI+CjxwYXRoIGQ9Ik00LjUgMTJIMjAuNSIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSIxLjQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPgo8cGF0aCBkPSJNNC41IDYuMjVIMjAuNSIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSIxLjQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPgo8cGF0aCBkPSJNNC41IDE3Ljc1SDIwLjUiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iMS40IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4KPC9nPgo8ZGVmcz4KPGNsaXBQYXRoIGlkPSJjbGlwMF8xMTc4N184Nzc2NyI+CjxyZWN0IHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgZmlsbD0id2hpdGUiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDAuNSkiLz4KPC9jbGlwUGF0aD4KPC9kZWZzPgo8L3N2Zz4K" width="24" height="24"></a>
                        </div>
                        <div class="fsghtertv logo-box">
                            <img src="images/logo.svg" width="150" height="30" title="Flipkart">
                        </div>
                    </div>
                    <div class="right-area _2msBFL">
                        <div class="mnjdd">
                            <a class="vbCXhM _1krdK5" href=""><img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIj4KICA8ZyBjbGlwLXBhdGg9InVybCgjY2xpcDBfMTE1NzBfODc5OTgpIj4KICAgIDxwYXRoIGQ9Ik0xOCAyMC4yNVYzLjc1QzE4IDIuOTIxNTcgMTcuMzI4NCAyLjI1IDE2LjUgMi4yNUw3LjUgMi4yNUM2LjY3MTU3IDIuMjUgNiAyLjkyMTU3IDYgMy43NUw2IDIwLjI1QzYgMjEuMDc4NCA2LjY3MTU3IDIxLjc1IDcuNSAyMS43NUgxNi41QzE3LjMyODQgMjEuNzUgMTggMjEuMDc4NCAxOCAyMC4yNVoiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iMS40IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4KICAgIDxwYXRoIGQ9Ik0xMiAxMC4xMDU1TDEyIDE3LjYwNTUiIHN0cm9rZT0iYmxhY2siIHN0cm9rZS13aWR0aD0iMS40IiBzdHJva2UtbGluZWNhcD0icm91bmQiIHN0cm9rZS1saW5lam9pbj0icm91bmQiLz4KICAgIDxwYXRoIGQ9Ik05Ljc1IDE1LjM1NTVMMTIgMTcuNjA1NUwxNC4yNSAxNS4zNTU1IiBzdHJva2U9ImJsYWNrIiBzdHJva2Utd2lkdGg9IjEuNCIgc3Ryb2tlLWxpbmVjYXA9InJvdW5kIiBzdHJva2UtbGluZWpvaW49InJvdW5kIi8+CiAgICA8cGF0aCBkPSJNMTAuNSA0LjVIMTMuNSIgc3Ryb2tlPSJibGFjayIgc3Ryb2tlLXdpZHRoPSIxLjQiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPgogIDwvZz4KICA8ZGVmcz4KICAgIDxjbGlwUGF0aCBpZD0iY2xpcDBfMTE1NzBfODc5OTgiPgogICAgICA8cmVjdCB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIGZpbGw9IndoaXRlIi8+CiAgICA8L2NsaXBQYXRoPgogIDwvZGVmcz4KPC9zdmc+Cg==" class="_1XmrCc" width="24" height="24" alt="Get App"></a>
                        </div>
                        <div class="dwddsad">
                            <a class="_1krdK5 vbCXhM" href="" title="Login"><img src="images/profile.svg" alt="Login" class="_1XmrCc _2zJ7Pb" width="24" height="24"><div class="uiU-ZX">Login</div></a>
                        </div>
                        <div class="cart">
                        <a href="" title="Cart" class="_3RX0a-"><img src="images/cart.svg" alt="Cart" class="_1XmrCc" width="24" height="24"></a>
                        </div>
                    </div>
                </div>
            </header>
            <div class="search-area hhHGh7 header" id="myHeader">
                <div class="ffggh556">
                <div class="dfg4543"><img src="images/b05dc6a8-7e45-48ef-8f27-482e3a02bd67.png" loading="eager" alt="" srcset="images/b05dc6a8-7e45-48ef-8f27-482e3a02bd67_1.png 1x, images/b05dc6a8-7e45-48ef-8f27-482e3a02bd67_2.png 2x" style="width: 100%; height: 100%; margin: auto; object-fit: cover; opacity: 1;"><img src="images/fk-default-image-75ff340b.png" loading="eager" alt="" style="width: 100%; height: 100%; margin: auto; position: absolute; inset: 0px; padding: inherit; object-fit: cover; opacity: 0;"></div>
                    <input type="text" class="r-102gzdx" placeholder="Search for Products, Brands and More">
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="slider">
                <div class="rocw">
                    <div class="cocl-sm-12">
                        <div id="carouselExampleIndicators" class="carousel carousel-dark slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="2" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="3" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="4" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="5" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="6" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="7" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="8" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="9" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="10" class=""></li>
                                                            </ol>
                            <div class="carousel-inner">
                                                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723221950-ban1.png" alt="banner1">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723221971-ban2.png" alt="banner2">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723221982-ban3.png" alt="banner3">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723221995-ban4.png" alt="banner4">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222013-ban5.png" alt="banner5">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222023-ban6.png" alt="banner6">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222038-ban7.png" alt="banner7">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222049-ban8.png" alt="banner8">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222058-ban9.png" alt="banner9">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222069-ban10.png" alt="banner10">
                                </div>
                                                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="categories">
                <div class="cat-list">
                                                <a class="category" href="mobiles.php">
                            <img src="images/Category-09-08-2024-1723223746-0c8bb53f8422f450.webp" alt="Mobiles">
                            <!-- <small style="font-size: 11px;">Mobiles</small> -->
                        </a>
                                            <a class="category" href="rakhi-special.php">
                            <img src="images/Category-09-08-2024-1723223895-39162dda5b6e35eb.webp" alt="Rakhi Special">
                            <!-- <small style="font-size: 11px;">Rakhi Special</small> -->
                        </a>
                                            <a class="category" href="beauty-foods-toys.php">
                            <img src="images/Category-09-08-2024-1723223772-c9fc2bd10675ea32.webp" alt="Beauty, Foods Toys">
                            <!-- <small style="font-size: 11px;">Beauty, Foods Toys</small> -->
                        </a>
                                            <a class="category" href="tv-appliances.php">
                            <img src="images/Category-09-08-2024-1723223809-7cd1f8fcb7d048ae.webp" alt="TV &amp; Appliances">
                            <!-- <small style="font-size: 11px;">TV & Appliances</small> -->
                        </a>
                                            <a class="category" href="home-furniture.php">
                            <img src="images/Category-09-08-2024-1723223842-1fe93a653e818ee9.webp" alt="Home &amp; Furniture">
                            <!-- <small style="font-size: 11px;">Home & Furniture</small> -->
                        </a>
                                            <a class="category" href="smart-gadgets.php">
                            <img src="images/Category-09-08-2024-1723223860-74c8d813b99ed432.webp" alt="Smart Gadgets">
                            <!-- <small style="font-size: 11px;">Smart Gadgets</small> -->
                        </a>
                                            <a class="category" href="grocery.php">
                            <img src="images/Category-09-08-2024-1723223879-f069d5e1df3b5d25.webp" alt="Grocery">
                            <!-- <small style="font-size: 11px;">Grocery</small> -->
                        </a>
                                    </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="products" id="products"> 
                <div class="product-list">
                
                         <a href="iphone-16.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/-original-imah4jz64htqmsxg.jpeg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> iPhone 16 Pro Max 512 GB                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹164,900</span>
                                <span class="sell-price">₹1600</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                         <a href="iphone.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/apple-iphone-14-pro-max-256-gb-deep-purple-6-gb-ram-.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> iPhone 14 Pro Max 256 GB                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹136,000</span>
                                <span class="sell-price">₹1000</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="samsung-galaxy.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/81vxWpPpgNL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Samsung</span> Galaxy S24 Ultra 5G AI Smartphone (Titanium Gray, 12GB, 512GB Storage)                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹139,000</span>
                                <span class="sell-price">₹989</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="iphone-15.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71zFRCcMS2L._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> iPhone 15 Plus (128 GB)                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹89,000</span>
                                <span class="sell-price">₹896</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="samsung.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/samsung-galaxy-z-fold-4-256-gb-beige-12-gb-ram-.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Samsung</span> Galaxy Z Fold 4 256 GB (Beige, 12 GB RAM)                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹146,000</span>
                                <span class="sell-price">₹969</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="vivo-v27.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71waR9n2enL._SX522_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">VIVO</span> V27 5G (Magic Blue, 128 GB) (8 GB RAM)                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">97% off</span>
                                <span class="mrp-price line-through">₹25,999</span>
                                <span class="sell-price">₹698</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 25 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="realme.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/81GNHx0grQL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Realme</span> 12 Pro+ 5G Submarine Blue, 12GB RAM, 256GB Storage                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">97% off</span>
                                <span class="mrp-price line-through">₹31,999</span>
                                <span class="sell-price">₹697</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="redmi.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/7b66930168d5b7b3c3d0cce70322e77b!400x400!85.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Redmi</span> Note 13 Pro+ 5G                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹35,999</span>
                                <span class="sell-price">₹669</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 25 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="dell.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71mBe9xEEdL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Dell</span> Inspiron 7441 Plus Laptop Built in AI Snapdragon X Plus X1P 64 100 16GB LPDDR5X  512GB SSD  Qualcomm GPU 14                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹111,990</span>
                                <span class="sell-price">₹959</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 25 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="apple-2024.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71ItMeqpN3L._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> 2024 MacBook Air  Laptop with M3 chip(13.6) Liquid Retina Display, 8GB Unified Memory, 256GB SSD Storage                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹130,000</span>
                                <span class="sell-price">₹950</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 25 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="hp-laptop.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71wMYNf8MZL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">HP</span> Laptop 15s, AMD Ryzen 3 5300U, 15.6-inch FHD, 8GB DDR4, 512GB                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹31,999</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="samsung-633.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/61QKzOZbl8L._SY741_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Samsung</span> 633 L 3 Star  Frost Free  Double Door  Convertible 5 in 1 Digital Inverter Side By Side Refrigerator with AI  WiFi &amp; Water &amp; Ice Dispenser RS78CG8543S9HL Silver Refined Inox 2024 Model                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹111,490</span>
                                <span class="sell-price">₹790</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="lg.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/61Z%2BPDXEJkL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">LG</span> 833 L Frost Free Smart Inverter Compressor Wi Fi Side By Side 5 Star Appliance G c B307Ssvl  Noble Steel2 Door Cooling Hygiene Fresh                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹94,990</span>
                                <span class="sell-price">₹790</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="panasonic.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71hnes2pyTL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Panasonic</span> 1.5 Ton 5 Star Wi Fi Inverter Smart Split AC Copper 7 in 1 Convertible with additional AI Mode 4 Way Swing  X Air Purification Technology  CS CU HU18ZKYF 2023 Model White                                 </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹54,999</span>
                                <span class="sell-price">₹789</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 25 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="daikin.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71KsH42yyTL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Daikin</span> 1.8 Ton 3 Star Hot Cold Inverter Split AC Copper PM 2.5 Filter FTHT60UV White                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹62,990</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="sony.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71j3bPnm%2BUL._SX522_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Sony</span> Alpha ILCE 7M3K Full Frame 24.2MP Mirrorless Digital SLR Camera with 28 70mm Zoom Lens  4K Full Frame  Real Time Eye Auto Focus LCD Low Light Camera   Black                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹139,000</span>
                                <span class="sell-price">₹650</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="nikon.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/81WtQ64-SOL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Nikon</span> D850 45.7MP Digital SLR Camera (Black) with AF-S Nikkor 24-120mm F4G ED VR Lens and 64GB Memory Card                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹129,000</span>
                                <span class="sell-price">₹650</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="ifb.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/61F9bBjEuUL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">IFB</span> Laundrimagic 3-in-1 8.5 Kg/6.5 Kg/2.5 Kg Inverter Washer Dryer Refresh (Executive ZXM, Mocha)                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹58,490</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="ifb1.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/-original-imaghuqxmy3bhzds.jpeg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">IFB</span> 6 Kg 5 Star AI Powered Fully Automatic Front Load Washing Machine                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">97% off</span>
                                <span class="mrp-price line-through">₹22,999</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 25 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="symphony.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/51Q5OzAoS0L._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Symphony</span> Touch 35 Personal Air Cooler For Home with Honeycomb Pads, Powerful Blower, i-Pure Technology and Cool Flow Dispenser (35L, White)                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">94% off</span>
                                <span class="mrp-price line-through">₹10,999</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 25 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="crompton.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/51E-OaCxahL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Crompton</span> Optimus Desert Air Cooler- 100L with 18 Fan, Everlast Pump, Large  Easy Clean Ice Chamber, Humidity Control White                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">95% off</span>
                                <span class="mrp-price line-through">₹13,999</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="apple-airpods.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/61sRKTAfrhL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> AirPods Pro (2nd Generation) with MagSafe Case(White)                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">97% off</span>
                                <span class="mrp-price line-through">₹21,999</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="oneplus-buds.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/MP000000018527675_658Wx734H_202308011615031.jpeg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">ONEPLUS</span> Buds Pro 2R BT with Adaptive Noise Cancellation Earbuds (Misty White)                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">95% off</span>
                                <span class="mrp-price line-through">₹9,999</span>
                                <span class="sell-price">₹489</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="apple-watch.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/91v9yAPw3-L._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> Watch Ultra GPS  Cellular 49 mm smart watch wRugged Titanium Case Starlight Alpine Loop Small Fitness Tracker                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹88,000</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="motorola.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/617WN7I3E4L._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Motorola</span> razr 40 Ultra (Glacier Blue, 8GB RAM, 256GB Storage)External AMOLED Display                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">98% off</span>
                                <span class="mrp-price line-through">₹41,999</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="zebronics.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71r-bf42LqL._SX522_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Zebronics</span> Juke bar 9550 pro 5.2 Soundbar (625 Watts)Dolby Audio                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">94% off</span>
                                <span class="mrp-price line-through">₹9,999</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Lowest Price in 30 days</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 25 Sep</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="boat.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71WFi0rx5PL._SX522_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">boAt</span> Aavante Bar 5400D with 550W Dolby Audio 5.1 Channel with wireless subwoofer                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">95% off</span>
                                <span class="mrp-price line-through">₹11,899</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz " style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Saver Deal</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="powermax.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/513XijizZOL._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">PowerMax</span> Fitness TD-A1 Motorised Foldable Treadmill for Home User Wt. 100kg 15 Lvl Auto-Incline Running Machine                                </h3>
                            <div class="product-price">
                                <span class="off-percentage">95% off</span>
                                <span class="mrp-price line-through">₹16,999</span>
                                <span class="sell-price">₹689</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star half"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                      
                </div>
            </div>
        </div>



    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.lazyload.min.js"></script> 
    <script src="js/main.js"></script>  
   
    

</body></html>