if (isset($_POST['logout'])) {
    session_destroy();
    header("Location: login.php"); // Redirect to login page after logout
}