<!DOCTYPE html><html lang="en-IN"><head>

    <title>Online Shopping Site for Lifestyle, Mobiles, Electronics, Furniture, Grocery, Books &amp; More. Best Offers!</title>
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    
    <meta name="Keywords" content="Online Shopping in India,online Shopping store,Online Shopping Site,Buy Online,Shop Online,Online Shopping, Fliipkart">
    <meta name="Description" content="India's biggest online store for Mobiles, Fashion (Clothes/Shoes), Electronics, Home Appliances, Books, Home, Furniture, Grocery, Jewelry, Sporting goods, Beauty &amp; Personal Care and more! Find the largest selection from all brands at the lowest prices in India. &amp; more.">
    <meta property="og:title" content="Online Shopping India Lifestyle Mobile, Cameras, &amp; more Online @ Fliipkart.com">
    <meta name="theme-color" content="#2874f0" id="themeColor">
    <meta name="viewport" content="width=device-width,minimum-scale=1,user-scalable=no">
    <link rel="shortcut icon" href="images/favicon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main1.css">
    <link rel="stylesheet" href="css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
    <script src="js/jquery.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&amp;display=swap" rel="stylesheet">
    <script>
        var MAIN_URL = "";
    </script>
 
</head>
<body class="expansion-alids-init" cz-shortcut-listen="true">
                 
        <div class="container-fluid">
            <div class="_1FWdmb sticky" style="background-color: #2874f0">
                <div class="d-flex align-items-center">
                    <a class="_3NH1qf " id="back-btn">
                        <svg width="19" height="16" viewBox="0 0 19 16" xmlns="http://www.w3.org/2000/svg"><path d="M17.556 7.847H1M7.45 1L1 7.877l6.45 6.817" stroke="#fff" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"></path></svg>
                    </a>
                    <a class="_3NH1qf d-none" id="showmenu">
                        <svg width="100%" height="100%" fill="none" xmlns="http://www.w3.org/2000/svg" mt="5" iconsize="24" class="sc-gswNZR jQgwzc">
                            <path d="M2 17.2222C2 17.8359 2.49746 18.3333 3.11111 18.3333H20.8889C21.5025 18.3333 22 17.8359 22 17.2222C22 16.6086 21.5025 16.1111 20.8889 16.1111H3.11111C2.49746 16.1111 2 16.6086 2 17.2222ZM2 11.6667C2 12.2803 2.49746 12.7778 3.11111 12.7778H20.8889C21.5025 12.7778 22 12.2803 22 11.6667C22 11.053 21.5025 10.5556 20.8889 10.5556H3.11111C2.49746 10.5556 2 11.053 2 11.6667ZM3.11111 5C2.49746 5 2 5.49746 2 6.11111C2 6.72476 2.49746 7.22222 3.11111 7.22222H20.8889C21.5025 7.22222 22 6.72476 22 6.11111C22 5.49746 21.5025 5 20.8889 5H3.11111Z" fill="#333333"></path>
                        </svg>
                    </a>
                    <a class="Z4_K_h" style="width:auto;margin-right:10px;margin-left:10px" href="index.php"> <h1 class="ui2-heading">Smart Gadgets</h1></a>
                </div>
                <div class="header-menu">
                <div class="right-area _2msBFL">
                        <div class="dwddsad">
                            <a class="_1krdK5 vbCXhM" href="" title="Login"><img src="images/profile-white.svg" alt="Login" class="_1XmrCc _2zJ7Pb" width="24" height="24"><div class="uiU-ZX" style="color:white;">Login</div></a>
                        </div>
                        <div class="cart">
                        <a href="" title="Cart" class="_3RX0a-"><img src="images/cart-white.svg" alt="Cart" class="_1XmrCc" width="24" height="24"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="slider">
                <div class="rocw">
                    <div class="cocl-sm-12">
                        <div id="carouselExampleIndicators" class="carousel carousel-dark slide" data-ride="carousel">
                            <ol class="carousel-indicators">
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="1" class="active"></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="2" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="3" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="4" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="5" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="6" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="7" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="8" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="9" class=""></li>
                                                                    <li data-target="#carouselExampleIndicators" data-slide-to="10" class=""></li>
                                                            </ol>
                            <div class="carousel-inner">
                                                                <div class="carousel-item active">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723221950-ban1.png" alt="banner1">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723221971-ban2.png" alt="banner2">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723221982-ban3.png" alt="banner3">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723221995-ban4.png" alt="banner4">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222013-ban5.png" alt="banner5">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222023-ban6.png" alt="banner6">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222038-ban7.png" alt="banner7">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222049-ban8.png" alt="banner8">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222058-ban9.png" alt="banner9">
                                </div>
                                                                <div class="carousel-item ">
                                    <img class="d-block w-100" src="images/banner-09-08-2024-1723222069-ban10.png" alt="banner10">
                                </div>
                                                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="categories">
                <div class="cat-list">
                                                <a class="category" href="mobiles.php">
                            <img src="images/Category-09-08-2024-1723223746-0c8bb53f8422f450.webp" alt="Mobiles">
                            <!-- <small style="font-size: 11px;">Mobiles</small> -->
                        </a>
                                            <a class="category" href="rakhi-special.php">
                            <img src="images/Category-09-08-2024-1723223895-39162dda5b6e35eb.webp" alt="Rakhi Special">
                            <!-- <small style="font-size: 11px;">Rakhi Special</small> -->
                        </a>
                                            <a class="category" href="beauty-foods-toys.php">
                            <img src="images/Category-09-08-2024-1723223772-c9fc2bd10675ea32.webp" alt="Beauty, Foods Toys">
                            <!-- <small style="font-size: 11px;">Beauty, Foods Toys</small> -->
                        </a>
                                            <a class="category" href="tv-appliances.php">
                            <img src="images/Category-09-08-2024-1723223809-7cd1f8fcb7d048ae.webp" alt="TV &amp; Appliances">
                            <!-- <small style="font-size: 11px;">TV & Appliances</small> -->
                        </a>
                                            <a class="category" href="home-furniture.php">
                            <img src="images/Category-09-08-2024-1723223842-1fe93a653e818ee9.webp" alt="Home &amp; Furniture">
                            <!-- <small style="font-size: 11px;">Home & Furniture</small> -->
                        </a>
                                            <a class="category" href="smart-gadgets.php">
                            <img src="images/Category-09-08-2024-1723223860-74c8d813b99ed432.webp" alt="Smart Gadgets">
                            <!-- <small style="font-size: 11px;">Smart Gadgets</small> -->
                        </a>
                                            <a class="category" href="grocery.php">
                            <img src="images/Category-09-08-2024-1723223879-f069d5e1df3b5d25.webp" alt="Grocery">
                            <!-- <small style="font-size: 11px;">Grocery</small> -->
                        </a>
                                    </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="products" id="products"> 
                <div class="product-list">
                                        <a href="apple-2024.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71ItMeqpN3L._SX679_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Apple</span> 2024 MacBook Air  Laptop with M3 chip(13.6) Liquid Retina Display, 8GB Unified Memory, 256GB SSD Storage                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">99% off</span>
                                <span class="mrp-price line-through">₹130,000</span>
                                <span class="sell-price">₹950</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="zebronics.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71r-bf42LqL._SX522_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">Zebronics</span> Juke bar 9550 pro 5.2 Soundbar (625 Watts)Dolby Audio                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">94% off</span>
                                <span class="mrp-price line-through">₹9,999</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r r-18u37iz r-1awozwy" style="padding: 4px;"><div dir="auto" class="css-1rynq56" style="font-size: 12px;">Bank Offer</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by Tomorrow</span>
                            </div>
                        </div>
                    </a>  
                                        <a href="boat.php" class="product-card">
                        <div class="product-img" style="">
                            <div class="css-175coi2r">
                                <div class="css-17c5oi2r">
                                    <svg width="24" height="24" viewBox="0 0 256 256"><path fill="none" d="M0 0h256v256H0z"></path><path d="M128 216S28 160 28 92a52 52 0 0 1 100-20h0a52 52 0 0 1 100 20c0 68-100 124-100 124Z" fill="#fff" stroke="#B8BBBF" stroke-linecap="round" stroke-linejoin="round" stroke-width="12"></path></svg>
                                </div>
                            </div>
                            <div class="css-175oi2rd">
                                <div class="css-175oi2r66">
                                    <div class="g6gc556">
                                        <img src="images/8f8ed4e7-5572-4756-bbec-19df46cbac7d.png" loading="eager" alt="">
                                        
                                    </div>
                                </div>
                            </div>
                            <img src="images/71WFi0rx5PL._SX522_.jpg" alt="">
                        </div>
                        <div class="product-details">
                            <h3 class="product-name">
                                <span style="font-size: 14px;font-weight: 600;font-family: system-ui !important;color: black;margin-bottom: 2px;">boAt</span> Aavante Bar 5400D with 550W Dolby Audio 5.1 Channel with wireless subwoofer                            </h3>
                            <div class="product-price">
                                <span class="off-percentage">95% off</span>
                                <span class="mrp-price line-through">₹11,899</span>
                                <span class="sell-price">₹589</span>
                            </div>
                            
                            <div class="css-175oi2r" style="padding: 4px; border-radius: 2px; background-color: rgb(233, 222, 255);"><div dir="auto" class="css-1rynq56" style="background-color: rgba(0, 0, 0, 0); font-size: 12px; color: rgb(112, 72, 198); font-family: " roboto="" medium",="" roboto-medium,="" "droid="" sans",="" helveticaneue-medium,="" "helvetica="" neue="" sans-serif-medium;="" font-style:="" normal;"="">Top Discount of the Sale</div></div>                            <div class="rating-box">
                                <div class="jkfjh48">
                                    <div class="5gs5hhg">
                                        <ul class="star-list"><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star"></i></li><li><i class="star off"></i></li></ul>                                    </div>
                                    <div class="SSF4dsaf">
                                    <img src="images/SwOvZ3r.png" loading="eager" alt="">
                                    </div>
                                </div>
                            </div>
                            <div class="dilivery-msg">
                            <span class="ghghgh66">Free delivery by 25 Sep</span>
                            </div>
                        </div>
                    </a>  
                      
                </div>
            </div>
        </div>



    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.lazyload.min.js"></script> 
    <script src="js/main.js"></script>       
    

</body></html>