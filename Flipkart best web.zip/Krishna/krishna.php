<?php
$loginKey = 'HACKED';
?>