
<?php
session_start();
require 'config.php'; // Ensure this file contains your database connection details

// Initialize variables
$username = "";
$error = "";
$success = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);

    if (empty($username)) {
        $error = "Please enter a username.";
    } else {
        // Prepare and execute delete statement
        $stmt = $pdo->prepare("DELETE FROM users WHERE username = :username");
        $stmt->bindParam(':username', $username);
        
        if ($stmt->execute()) {
            if ($stmt->rowCount() > 0) {
                $success = "User '$username' deleted successfully.";
            } else {
                $error = "User '$username' not found.";
            }
        } else {
            $error = "Error deleting user.";
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete User</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script>
    <style>
        body {
            background-color: #000;
            color: white;
            font-family: Arial, sans-serif;
            position: relative;
            overflow: hidden;
            height: 100vh; /* Ensure body takes full height */
        }
        #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: 0; /* Send to back */
        }
        .content {
            position: relative;
            z-index: 1; /* Bring to front */
            text-align: center;
            padding: 20px;
        }
        .swimming-text {
            display: inline-block;
            animation: swim 2s ease-in-out infinite; /* Swimming animation */
            color: #00ff00; /* Light green color */
            text-shadow: 0 0 10px rgba(0, 255, 0, 0.8), 0 0 20px rgba(0, 255, 0, 0.6);
            margin-bottom: 30px; /* Space below the heading */
        }
        @keyframes swim {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-10px); /* Moves up */
            }
        }
        .input-red {
            color: red; /* Red text color */
        }
        .input-field {
            width: 80%; /* Set width to 80% */
            padding: 12px; /* Increase padding for better appearance */
            border: 2px solid #00ff00; /* Green border */
            border-radius: 8px; /* Rounded corners */
            background-color: transparent; /* Transparent background */
            color: white; /* Text color */
            font-size: 1rem; /* Font size */
        }
        .logo {
            margin: 20px auto; /* Centering the logo */
            width: 180px; /* Medium size */
            height: auto;
        }
    </style>
</head>
<body>
    <div id="particles-js"></div>
    <div class="content">
        <h1 class="text-3xl font-bold swimming-text">Delete User</h1>
        <img src="logo.png" alt="Logo" class="logo"> <!-- Logo positioned below the heading -->
        <div class="swimming-text">Fuck User Data</div> <!-- Swimming animation here -->
        <div class="mt-6">
            <form action="delete.php" method="POST">
                <div class="mb-4">
                    <input type="text" id="username" name="username" placeholder="Enter Username" class="input-field" required>
                </div>
                <div class="mt-4 flex justify-end">
                    <button type="submit" class="bg-red-500 text-white rounded-full px-4 py-2">Delete User</button>
                </div>
    </form>
            <?php if ($error): ?>
                <div class="mt-4 text-red-500"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php elseif ($success): ?>
                <div class="mt-4 text-green-500"><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
                </div>
        <div class="mt-6 text-center">
            <p>Want To Register User Details? <a class="text-blue-500" href="register.php">Click Here</a></p>

    <script>
        // Change input text color to red on focus
        const usernameInput = document.getElementById('username');
        
        usernameInput.addEventListener('focus', function() {
            this.classList.add('input-red');
        });

        usernameInput.addEventListener('blur', function() {
            this.classList.remove('input-red');
        });

        particlesJS("particles-js", {
            "particles": {
                "number": {
                    "value": 100,
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": {
                    "value": "#00ff00"
                },
                "shape": {
                    "type": "circle",
                    "stroke": {
                        "width": 0,
                        "color": "#000000"
                    },
                },
                "opacity": {
                    "value": 0.5,
                    "random": false,
                    "anim": {
                        "enable": false,
                    }
                },
                "size": {
                    "value": 3,
                    "random": true,
                },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#00ff00",
                    "opacity": 0.4,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 6,
                    "direction": "none",
                    "random": false,
                    "straight": false,
                    "out_mode": "out",
                    "bounce": false,
                }
            },
            "interactivity": {
                "detect_on": "canvas",
                "events": {
                    "onhover": {
                        "enable": true,
                        "mode": "grab"
                    },
                    "onclick": {
                        "enable": true,
                        "mode": "push"
                    },
                    "resize": true
                },
                "modes": {
                    "grab": {
                        "distance": 140,
                        "line_linked": {
                            "opacity": 1
                        }
                    },
                    "push": {
                        "particles_nb": 4
                    },
                }
            },
            "retina_detect": true
        });
    </script>
</body>
</html>