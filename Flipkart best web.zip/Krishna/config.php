<?php
$dsn = 'mysql:host=mysql12.serv00.com;dbname=m6778_cutehack';
$username = 'm6778_Cutehack';
$password = '123456krishna@A';
try {
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
}
?>