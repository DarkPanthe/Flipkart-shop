<?php
include 'krishna.php';

$auth = $_GET['auth'] ?? '';
if ($auth !== md5($loginKey)) {
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $newUpiID = $_POST['upiID'];
    $newLoginKey = $_POST['loginKey'];
    
    $fileContent = "<?php\n\$loginKey = '$newLoginKey';\n?>";
    file_put_contents('krishna.php', $fileContent);

    $upiFileContent = json_encode(['upi_id' => $newUpiID], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
    file_put_contents('upi.php', $upiFileContent);

    $success = 'Updated successfully!';
}
$loginKey = isset($loginKey) ? $loginKey : '';
$upiID = isset($upiID) ? $upiID : '';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>KRISHNA WEBS</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css" rel="stylesheet">
    <style>
        body {
            background: #000;
            overflow: hidden;
            color: #00ff00;
            font-family: 'Courier New', Courier, monospace;
        }

        #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            z-index: 0;
        }

        #text-particles {
            position: absolute;
            bottom: 20px; /* Position at the bottom */
            left: 50%;
            transform: translateX(-50%);
            font-size: 2rem; /* Adjusted size */
            font-weight: bold;
            color: rgba(0, 255, 0, 0.5);
            z-index: 1;
            white-space: nowrap;
            pointer-events: none; /* Prevent interaction */
            animation: swim 3s ease-in-out infinite;
            text-shadow: 0 0 10px #00ff00, 0 0 20px #00ff00;
        }

        @keyframes swim {
            0%, 100% {
                transform: translateX(-50%) translateY(0);
            }
            50% {
                transform: translateX(-50%) translateY(-10px); /* Adjust the float height */
            }
        }

        .card {
            padding: 20px;
            margin-top: 40px;
            border-radius: 20px;
            background: rgba(0, 0, 0, 0.8);
            box-shadow: 0 4px 20px rgba(0, 255, 0, 0.5);
            position: relative;
            z-index: 2;
        }

        b {
            font-weight: 800;
            color: #00ff00;
            text-shadow: 0 0 10px #00ff00, 0 0 20px #00ff00;
        }

        c {
            font-weight: 800;
            color: #808080;
        }

        .input-field input {
            color: #00ff00;
            text-shadow: 0 0 5px #00ff00;
        }

        .input-field label {
            color: #00ff00;
        }

        button {
            background-color: #28c76f;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #00ff00;
        }

        .success-message {
            background-color: rgba(40, 199, 111, 0.8);
            color: #000;
            border-radius: 10px;
        }
    </style>
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
</head>
<body>
    <div id="particles-js"></div>

    <div class="container">
        <h4 class="card center-align"><b>KRISHNA</b> <c>WEBS</c></h4>
        <form class="card center-align" method="post">
            <div class="input-field">
                <input type="text" id="upiID" name="upiID" value="<?php echo htmlspecialchars($upiID ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                <label for="upiID">UPI ID</label>
            </div>
            <div class="input-field">
                <input type="password" id="loginKey" name="loginKey" value="<?php echo htmlspecialchars($loginKey ?? '', ENT_QUOTES, 'UTF-8'); ?>" required>
                <label for="loginKey">Login Key</label>
            </div>
            <button type="submit" class="btn waves-effect waves-light">Update</button>
            <?php if (isset($success)): ?>
                <div class="card-panel success-message"><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?></div>
            <?php endif; ?>
        </form>
    </div>

    <div id="text-particles">MADE BY KRISHNA</div>

    <script>
        particlesJS("particles-js", {
            "particles": {
                "number": {
                    "value": 100,
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": {
                    "value": "#00ff00"
                },
                "shape": {
                    "type": "circle",
                    "stroke": {
                        "width": 0,
                        "color": "#000000"
                    },
                },
                "opacity": {
                    "value": 0.5,
                    "random": false,
                    "anim": {
                        "enable": false,
                    }
                },
                "size": {
                    "value": 3,
                    "random": true,
                },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#00ff00",
                    "opacity": 0.4,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 6,
                    "direction": "none",
                    "random": false,
                    "straight": false,
                    "out_mode": "out",
                    "bounce": false,
                }
            },
            "interactivity": {
                "detect_on": "canvas",
                "events": {
                    "onhover": {
                        "enable": true,
                        "mode": "grab"
                    },
                    "onclick": {
                        "enable": true,
                        "mode": "push"
                    },
                    "resize": true
                },
                "modes": {
                    "grab": {
                        "distance": 140,
                        "line_linked": {
                            "opacity": 1
                        }
                    },
                    "push": {
                        "particles_nb": 4
                    },
                }
            },
            "retina_detect": true
        });
    </script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            M.updateTextFields();
        });
    </script>
</body>
</html>