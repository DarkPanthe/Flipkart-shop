<?php
header('Content-Type: text/html; charset=UTF-8');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Failed - Flipkart</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f1f3f6;
            margin: 0;
            padding: 0;
        }
        .navbar, .footer {
            background-color: #2874f0;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
        }
        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }
        .footer {
            position: fixed;
            bottom: 0;
            height: 40px;
            width: 100%;
        }
        .footer img {
            width: 120px;
        }
        .navbar img {
            float: left;
            margin-left: -5px;
            width: 85px;
        }
        .container {
            background-color: #fff;
            width: 320px;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            text-align: center;
            margin: 0 auto;
            margin-top: 20px;
        }
        .error-message {
            color: #ff0000;
            font-size: 22px;
            margin-bottom: 20px;
            font-weight: bold;
        }
        .instructions {
            color: #777;
            font-size: 14px;
            margin-bottom: 20px;
            line-height: 1.5;
        }
        .btn {
            background-color: #2874f0;
            color: #fff;
            border: none;
            padding: 10px 15px;
            width: 90%;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            text-decoration: none;
            text-transform: uppercase;
            display: inline-block;
        }
        .btn:hover {
            background-color: #1a5bbd;
        }
        .success-icon {
            width: 100%;
        }
        h1 {
            color: #4caf50;
            font-size: 24px;
            margin-bottom: 10px;
        }
        p {
            color: #666;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .order-details p {
            color: #333;
            font-size: 14px;
            margin: 5px 0;
        }
        .btn {
            display: inline-block;
            margin: 15px 5px;
            padding: 10px 20px;
            border-radius: 5px;
            color: #fff;
            text-decoration: none;
            background-color: #2874f0;
            text-transform: uppercase;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #1a5bb5;
        }
        .cheif {
            margin-bottom: 100px;
        }
    </style>
</head>
<body>
<div class="cheif"></div>
<div class="navbar">
    <img src="img/logo.png" alt="Flipkart Logo">
</div>

<div class="container">
    <img src="img/failed.gif" alt="Success Icon" class="success-icon">
    <div class="error-message">
        Payment Failed
    </div>
    <div class="instructions">
        Unfortunately, your payment was not successful. Please pay & try again.
    </div>
    <a class="btn" href="index.php">Go Back to Home</a>
</div>

<div class="footer">
    <img src="https://img1a.flixcart.com/www/linchpin/fk-cp-zion/img/fk-logo_9fddff.png" alt="Flipkart Logo">
</div>

</body>
</html>