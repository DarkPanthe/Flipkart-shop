
<?php
session_start();
require 'config.php'; // This file should contain your database connection details

// Function to connect to the database
function connectDB() {
    global $pdo;
    if (!$pdo) {
        die("Database connection failed.");
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $userAgent = $_SERVER['HTTP_USER_AGENT'];

    connectDB();

    // Fetch user from the database
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Check if the user exists
    if ($user) {
        // Verify the password
        if (password_verify($password, $user['password'])) {
            // Check if user is an admin
            if ($user['admin'] == 1) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                header("Location: iphone.php");
                exit();
            } else {
                // Match user-agent
                if ($user['user_agent'] == $userAgent) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    header("Location: login.php"); // Redirect to user home page
                    exit();
                } else {
                    $error = "User-Agent does not match.";
                }
            }
        } else {
            $error = "Incorrect password.";
        }
    } else {
        $error = "User not found.";
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Screen</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/particles.js/2.0.0/particles.min.js"></script>
    <style>
        body {
            background-color: #000; /* Solid black background */
            font-family: 'Arial', sans-serif;
            overflow: hidden; /* Prevent scroll bars */
        }
        #particles-js {
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            z-index: -1; /* Send behind other elements */
        }
        .looping-text {
            display: inline-block;
            animation: loop-animation 2s ease-in-out infinite; /* Looping animation */
            background: linear-gradient(45deg, #00ff00, #ff00ff, #00ffff);
            background-size: 200% 200%;
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            animation: color-change 3s ease-in-out infinite; /* Color animation */
        }
        @keyframes loop-animation {
            0% {
                transform: translateY(0) rotate(0deg);
            }
            25% {
                transform: translateY(-5px) rotate(-5deg);
            }
            50% {
                transform: translateY(5px) rotate(5deg);
            }
            75% {
                transform: translateY(-5px) rotate(-5deg);
            }
            100% {
                transform: translateY(0) rotate(0deg);
            }
        }
        @keyframes color-change {
            0% {
                background-position: 0% 50%;
            }
            100% {
                background-position: 100% 50%;
            }
        }
        .logo {
            width: 150px; /* Adjust width */
            height: auto; /* Maintain aspect ratio */
            margin: 20px 0; /* Space above and below the logo */
        }
    </style>
</head>
<body>
    <div id="particles-js"></div>
    <div class="flex flex-col items-center min-h-screen">
        <form action="login.php" method="POST" class="text-center p-8 rounded-lg shadow-lg w-full max-w-sm mt-10">
            <h1 class="text-white text-4xl font-bold mb-2 looping-text">Krishna Web Panel</h1> <!-- Looping color animation -->
            <img src="logo.png" alt="Logo" class="logo mx-auto"> <!-- Centered logo -->
            <p class="text-gray-400 mb-8">Login</p>
            <p class="text-white text-lg mb-4">Login To Continue</p>
            <div class="mb-4">
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                        <i class="fas fa-user text-gray-400"></i>
                    </span>
                    <input type="text" name="username" placeholder="Username" class="pl-10 pr-4 py-2 rounded-full w-full bg-white text-gray-700 focus:outline-none focus:ring focus:ring-red-500" required>
                </div>
            </div>
            <div class="mb-8">
                <div class="relative">
                    <span class="absolute inset-y-0 left-0 flex items-center pl-3">
                        <i class="fas fa-key text-red-500"></i>
                    </span>
                    <input type="password" name="password" placeholder="Password" class="pl-10 pr-4 py-2 rounded-full w-full bg-white text-gray-700 focus:outline-none focus:ring focus:ring-red-500" required>
                </div>
            </div>
            <button type="submit" class="bg-red-500 text-white py-2 px-6 rounded-full flex items-center justify-center mx-auto">
                Login!
                <i class="fas fa-arrow-right ml-2"></i>
            </button>
        </form>
          <?php if (isset($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>
    </div>
    <script>
        particlesJS("particles-js", {
            "particles": {
                "number": {
                    "value": 100,
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": {
                    "value": "#00ff00"
                },
                "shape": {
                    "type": "circle",
                    "stroke": {
                        "width": 0,
                        "color": "#000000"
                    },
                },
                "opacity": {
                    "value": 0.5,
                    "random": false,
                    "anim": {
                        "enable": false,
                    }
                },
                "size": {
                    "value": 3,
                    "random": true,
                },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#00ff00",
                    "opacity": 0.4,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 6,
                    "direction": "none",
                    "random": false,
                    "straight": false,
                    "out_mode": "out",
                    "bounce": false,
                }
            },
            "interactivity": {
                "detect_on": "canvas",
                "events": {
                    "onhover": {
                        "enable": true,
                        "mode": "grab"
                    },
                    "onclick": {
                        "enable": true,
                        "mode": "push"
                    },
                    "resize": true
                },
                "modes": {
                    "grab": {
                        "distance": 140,
                        "line_linked": {
                            "opacity": 1
                        }
                    },
                    "push": {
                        "particles_nb": 4
                    },
                }
            },
            "retina_detect": true
        });
    </script>
</body>
</html>