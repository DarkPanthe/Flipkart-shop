<?php
header('Content-Type: text/html; charset=UTF-8');

function generateOrderId() {
    return strtoupper(uniqid('FK'));
}

$deliveryDate = date('d M, Y', strtotime('+7 days'));
$orderId = generateOrderId();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Success - Flipkart</title>
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            background-color: #f1f3f6;
            margin: 0;
            padding: 0;
        }
        .navbar, .footer {
            background-color: #2874f0;
            color: #fff;
            padding: 10px 20px;
            text-align: center;
        }
        .navbar {
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 1000;
        }
        .navbar img {
            float: left;
            margin-left: -5px;
            width: 85px;
        }
        .footer {
            position: fixed;
            bottom: 0;
            height: 40px;
            width: 100%;
        }
        .footer img, .navbar img {
            width: 120px;
        }
        .container {
            background-color: #fff;
            width: 320px;
            max-width: 400px;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            text-align: center;
            margin: 0 auto;
        }
        .success-icon {
            width: 100%;
        }
        h1 {
            color: #4caf50;
            font-size: 24px;
            margin-bottom: 10px;
        }
        p {
            color: #666;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .order-details p {
            color: #333;
            font-size: 14px;
            margin: 5px 0;
        }
        .btn {
            display: inline-block;
            margin: 15px 5px;
            padding: 10px 20px;
            border-radius: 5px;
            color: #fff;
            text-decoration: none;
            background-color: #2874f0;
            text-transform: uppercase;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #1a5bb5;
        }
        .cheif {
            margin-bottom: 100px;
        }
    </style>
</head>
<body>
<div class="cheif"></div>
<div class="navbar">
    <img src="img/logo.png" alt="Flipkart Logo">
</div>

<div class="container">
    <img src="img/success.gif" alt="Success Icon" class="success-icon">
    <h1>Payment Successful!</h1>
    <p>Your order has been placed successfully.</p>
    <div class="order-details">
        <p><strong>Order ID:</strong> <?php echo $orderId; ?></p>
        <p><strong>Total Amount:</strong> ₹<?php echo htmlspecialchars($_GET['amount']); ?></p>
        <p><strong>Expected Delivery:</strong> <?php echo $deliveryDate; ?></p>
    </div>
    <a class="btn" href="index.php">Continue Shopping</a>
</div>

<div class="footer">
    <img src="https://img1a.flixcart.com/www/linchpin/fk-cp-zion/img/fk-logo_9fddff.png" alt="Flipkart Logo">
</div>

</body>
</html>