<!DOCTYPE html><html lang="en-IN"><head>

    <title>Online Shopping Site for Lifestyle, Mobiles, Electronics, Furniture, Grocery, Books &amp; More. Best Offers!</title>
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Expires" content="-1">
    
    <meta name="Keywords" content="Online Shopping in India,online Shopping store,Online Shopping Site,Buy Online,Shop Online,Online Shopping, Fliipkart">
    <meta name="Description" content="India's biggest online store for Mobiles, Fashion (Clothes/Shoes), Electronics, Home Appliances, Books, Home, Furniture, Grocery, Jewelry, Sporting goods, Beauty &amp; Personal Care and more! Find the largest selection from all brands at the lowest prices in India. &amp; more.">
    <meta property="og:title" content="Online Shopping India Lifestyle Mobile, Cameras, &amp; more Online @ Fliipkart.com">
    <meta name="theme-color" content="#2874f0" id="themeColor">
    <meta name="viewport" content="width=device-width,minimum-scale=1,user-scalable=no">
    <link rel="shortcut icon" href="images/favicon.png">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/main1.css">
    <link rel="stylesheet" href="css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer">
    <script src="js/jquery.min.js"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Poppins&amp;display=swap" rel="stylesheet">
    <script>
        var MAIN_URL = "";
    </script>
</head>

<body class="expansion-alids-init" cz-shortcut-listen="true">
    <div id="container" style="overflow:hidden">
        <div style="height:100%" data-reactroot="">
            <div class="container-fluid p-3 header-container">
                <div class="row header">
                    <div class="col-1">
                        <div class="menu-icon" id="back-btn">
                            <svg width="19" height="16" viewBox="0 0 19 16" xmlns="http://www.w3.org/2000/svg">
                                <path d="M17.556 7.847H1M7.45 1L1 7.877l6.45 6.817" stroke="#000" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" fill="none"></path>
                            </svg> 
                        </div>
                    </div>
                    <div class="col-8">
                        <div class="menu-logo">
                            <h4 class="mb-0 mt-1 ms-2">Order Summary</h4>
                        </div>
                    </div>
                </div>
            </div>
            <div class="_1fhgRH max-height mb-70">
                <div class="card pt-1 mb-1">
                    <div class="progress-box mb-0">
                        <img class="w-100" src="images/progress-indicator-summary.png">
                    </div>
                </div>
                <div class="card px-3 py-4 mb-2">
                    <h3>Delivered to:</h3>
                    <div class="address-div mt-2">
                        <h4 class="customer-name" id="customer-name">
                        </h4>
                        <div class="mb-2 customer-address" id="customer-address"></div>
                        <div class="customer-contact" id="customer-contact"></div>
                        <p id="demo"></p>
                    </div>
                </div>
                <div class="card px-3 py-4 mb-2">
                    <ul class="list-group list-group-flush" id="deals">
                        <li class="list-group-item px-0" data-timer="2000">
                            <div class="flex recommended-product">
                                <img src="" id="item_image">
                                <div class="description">
                                    <div class="product-title mb-1" id="product-title"></div>
                                    <div class="product-detail mb-1" id="product-detail"></div>
                                    <img id="order-image" src="images/SwOvZ3r.png" width="77px">
                                </div>
                            </div>
                            <div class="flex recommended-product mt-3">
                                <div class="timer qty mx-4">
                                    Qty: 1
                                </div>
                                <div class="description">
                                    <div class="price flex">
                                        <span class="discount" id="discount"></span> &nbsp; &nbsp;
                                        <span class="strike mrp" id="mrp"></span> &nbsp; &nbsp;
                                        <span class="selling_price" id="selling_price"></span>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
                <div class="card px-3 py-4 mb-2" id="price-detail">
                    <h3>Price Details</h3>
                    <div class="price-detail-div mt-2">
                        <div class="product-price-list my-3">
                            <span class="title">Price (1 item)</span>
                            <span class="data mrp me-0 td-none" id="total-price"></span>
                        </div>
                        <div class="product-price-list my-3">
                            <span class="title">Discount</span>
                            <span class="data discount-amt text-success" id="disc-price"></span>
                        </div>
                        <div class="product-price-list my-3">
                            <span class="title">Delivery Charges</span>
                            <span class="data text-success">FREE Delivery </span>
                        </div>
                        <div class="product-price-list my-3 pt-3 total">
                            <span class="title">Total Amount </span>
                            <span class="data selling_price" id="total-price1"></span>
                        </div>
                        <div class="product-price-list mt-3 pt-3 saved-div">
                            <span class="text-success">You will save <span class="discount-amt" id="discount-amt" style="display: contents;font-size: 16px;font-weight: 600;"></span> on this order</span>
                        </div>
                    </div>
                </div>
                <div class="sefty-banner">
                    <img class="sefty-img" src="images/9b179a8a-a0e2-497b-bd44-20aa733dc0ec.webp" loading="lazy" alt="">
                    <div dir="auto" class="sefty-txt">Safe and secure payments. Easy returns. 100% Authentic products.</div>
                </div>
                <div class="button-container flex p-3 bg-white">
                    <div class="col-6 footer-price">
                        <span class="strike mrp ms-0 mb-1" id="mrp-footer"></span>
                        <span class="selling_price" id="selling_price-footer"></span>
                    </div>
                    <button class="buynow-button product-page-buy col-6 btn-continue" onclick="btnContinue();">
                        Continue
                    </button>
                </div>
            </div>

        </div>
        <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.lazyload.min.js"></script> 
    <script src="js/main.js"></script>   
        <script defer="" src="js/manage_summary.js"></script>   
        <script>
            $("#back-btn").on("click", function() {
                        history.back();
                    });
        </script> 
    
</div></body></html>