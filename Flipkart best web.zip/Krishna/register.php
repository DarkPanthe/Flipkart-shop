<?php
// Include the config file
include 'config.php';

// Initialize variables
$username = $password = $user_agent = "";
$error = $success = "";

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);
    $user_agent = $_SERVER['HTTP_USER_AGENT'];

    if (empty($username) || empty($password) || empty($user_agent)) {
        $error = "Please fill in all fields.";
    } else {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert into database
        try {
            $stmt = $pdo->prepare("INSERT INTO users (username, password, user_agent) VALUES (?, ?, ?)");
            $stmt->execute([$username, $hashed_password, $user_agent]);
            $success = "Registration successful!";
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Krishna Web Panel - Register Users</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/particles.js/2.0.0/particles.min.js"></script>
    <style>
        body {
            background-color: black;
            color: white;
            font-family: Arial, sans-serif;
            overflow: hidden; /* Prevent scrolling */
        }
        #particles-js {
            position: absolute;
            width: 100%;
            height: 100%;
            z-index: -1; /* Send particles behind other elements */
        }

        .swimming-text {
            display: inline-block;
            animation: shake 1s infinite; /* Use the shake animation */
            color: #00ff00; /* Light green color */
            text-shadow: 0 0 10px rgba(0, 255, 0, 0.8), 0 0 20px rgba(0, 255, 0, 0.6);
            margin-bottom: 30px; /* Space below the heading */
        }

        @keyframes shake {
            0% { transform: translate(1px, 1px) rotate(0deg); }
            25% { transform: translate(-1px, -2px) rotate(-1deg); }
            50% { transform: translate(-1px, 2px) rotate(1deg); }
            75% { transform: translate(1px, 2px) rotate(0deg); }
            100% { transform: translate(1px, -1px) rotate(1deg); }
        }

        .content {
            position: relative;
            z-index: 1; /* Bring to front */
            text-align: center;
            padding: 20px;
        }
    </style>
</head>
<body class="flex flex-col items-center justify-center min-h-screen">
    <div id="particles-js"></div> <!-- Particles Background -->
    <h1 class="text-3xl font-bold swimming-text">Krishna Web Panel</h1>
    <p class="text-sm">04 August 2023 - 7:55 PM</p>
    <div class="mt-6">
        <img alt="Admin Image" class="rounded-full" height="150" src="logo.png" width="150"/>
    </div>
    <div class="mt-6 text-center">
        <h2 class="text-xl font-semibold">Register Users</h2>
    </div>
    <div class="mt-4 w-80">
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
            <div class="flex items-center bg-white text-black rounded-full p-2 mb-4">
                <i class="fas fa-user ml-2"></i>
                <input class="bg-transparent flex-1 ml-2 outline-none" name="username" placeholder="Username" type="text" required/>
            </div>
            <div class="flex items-center bg-white text-black rounded-full p-2 mb-4">
                <i class="fas fa-key ml-2 text-red-500"></i>
                <input class="bg-transparent flex-1 ml-2 outline-none" name="password" placeholder="Password" type="password" required/>
            </div>
            <div class="flex items-center bg-white text-black rounded-full p-2 mb-4">
                <i class="fas fa-key ml-2 text-red-500"></i>
                <input class="bg-transparent flex-1 ml-2 outline-none" name="user_agent" placeholder="User Agent" type="text" required/>
            </div>
            <div class="mt-6 flex justify-end">
                <button type="submit" class="bg-red-500 text-white rounded-full px-6 py-2 flex items-center">
                    Register!
                    <i class="fas fa-arrow-right ml-2"></i>
                </button>
            </div>
        </form>
        <?php if ($error): ?>
            <div class="mt-4 text-red-500"><?php echo htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php elseif ($success): ?>
            <div class="mt-4 text-green-500"><?php echo htmlspecialchars($success, ENT_QUOTES, 'UTF-8'); ?></div>
        <?php endif; ?>
    </div>
    <div class="mt-6 text-center">
        <p>Want To Edit User Details? <a class="text-blue-500" href="#">Click Here</a></p>
    </div>
    <script>
        particlesJS("particles-js", {
            "particles": {
                "number": {
                    "value": 100,
                    "density": {
                        "enable": true,
                        "value_area": 800
                    }
                },
                "color": {
                    "value": "#00ff00"
                },
                "shape": {
                    "type": "circle",
                    "stroke": {
                        "width": 0,
                        "color": "#000000"
                    },
                },
                "opacity": {
                    "value": 0.5,
                    "random": false,
                    "anim": {
                        "enable": false,
                    }
                },
                "size": {
                    "value": 3,
                    "random": true,
                },
                "line_linked": {
                    "enable": true,
                    "distance": 150,
                    "color": "#00ff00",
                    "opacity": 0.4,
                    "width": 1
                },
                "move": {
                    "enable": true,
                    "speed": 6,
                    "direction": "none",
                    "random": false,
                    "straight": false,
                    "out_mode": "out",
                    "bounce": false,
                }
            },
            "interactivity": {
                "detect_on": "canvas",
                "events": {
                    "onhover": {
                        "enable": true,
                        "mode": "grab"
                    },
                    "onclick": {
                        "enable": true,
                        "mode": "push"
                    },
                    "resize": true
                },
                "modes": {
                    "grab": {
                        "distance": 140,
                        "line_linked": {
                            "opacity": 1
                        }
                    },
                    "push": {
                        "particles_nb": 4
                    },
                }
            },
            "retina_detect": true
        });
    </script>
</body>
</html>